# Compilar e executar C++ no aparelho

```
fonte --sha256(fonte+flags+toolchain)--> cache hit? --sim--> .so
                                           | não
              fork: clang [+ ld.lld] --> .so (rename atômico, 0555)
              fork: dlopen(.so) -> main(argc, argv)   (stdin/stdout por pipe, timeout, SIGKILL no grupo)
```
Compilar e rodar acontecem em processos filhos isolados: crash, laço infinito ou `exit()` não derrubam o app.
`ExecResult` traz os tempos (compilação/execução) e se houve cache hit. PCH (`<iostream>`, `<vector>`...) é
gerado uma vez e reaproveitado.

## O que falta: ter clang e lld que rodem NO Android
O NDK só traz clang/lld para Linux/Mac/Windows. Para rodar no aparelho é preciso um clang+lld compilados para
Android (o Termux publica pacotes assim; ou compile o LLVM com o NDK). Escolha o modo conforme a distribuição:

| Modo | Como o clang é executado | Quando serve | Custo |
|---|---|---|---|
| **A. Executável no APK** | `libclang.so`/`liblld.so` em `jniLibs/<abi>/` (nativeLibraryDir), `exec` direto | APK sideload (GitHub Actions) e qualquer targetSdk | APK bem maior; `extractNativeLibs=true` |
| **B. Executável em filesDir** | binários baixados pelo ToolchainManager | só com `targetSdk <= 28` (como o Termux); sideload | pode parar de funcionar em versões futuras do Android |
| **C. Biblioteca em processo** | `libci_clang_host.so` exporta `ci_clang_main(argc, argv)` (clang + `lld::lldMain` em processo) | Play Store (targetSdk alto) | exige código/build customizado de LLVM (NÃO escrito) |

O código C++ já suporta A/B (`initExecutables`) e C (`initHostLibrary`). O modo A/B não tem nenhum código
customizado de LLVM: só executa os binários.

### De onde vêm os binários: workflow `build-llvm-android.yml`
Manual (Actions -> "Build LLVM for Android" -> Run). Compila clang e lld **estáticos** para arm64-v8a e armeabi-v7a
(só backends AArch64/ARM, sem zlib/zstd/xml: nada para relocar) e já gera, por ABI, `jniLibs/<abi>/libclang.so`,
`liblld.so` e `sysroot-<abi>.zip` (+ SHA256). Demora horas; rode uma vez. Com `publish=true` cria uma Release.
**Nunca foi executado**: espere ajustes de flags do CMake na primeira rodada.
Dois detalhes que o código já trata: o driver precisa de `--driver-mode=g++` (o executável se chama libclang.so,
não clang++) e o lld precisa se chamar `ld.lld` (o app cria o symlink `workDir/ld.lld -> liblld.so`).

### Modo A (recomendado para APK do GitHub)
1. Coloque `libclang.so` (o executável clang) e `liblld.so` (o `ld.lld`) em `app/src/main/jniLibs/arm64-v8a/` e
   `armeabi-v7a/`.
2. Compile com `gradle assembleDebug -Pci.clangInApk=true`. Isso liga `useLegacyPackaging` e desliga o strip dos
   dois executáveis (já está no `build.gradle.kts`, só ativa com a propriedade; muda o empacotamento do app
   inteiro, inclusive Chaquopy: teste).
3. `NativeExec.initExecutables(toolchainDir, NativeExec.apkTool(ctx, "clang"), NativeExec.apkTool(ctx, "lld"), ...)`.

### Pacote de sysroot (todos os modos)
`tools/make_sysroot_pack.sh <NDK> <triple> <clang-resource-dir> <out.zip>` monta `sysroot/` (headers + libs do NDK) e
`clang-resource/` (headers builtin). O `clang-resource` PRECISA ser do mesmo clang que será executado.
Publique o zip (ex.: GitHub Release) e use o `ToolchainManifest(id, url, sha256, size)` com o `ToolchainManager`.

## Tela de teste
O ícone **CI Exec Demo** abre um editor simples + Executar/Cancelar e mostra status, saída e tempos. Fluxo:
instalar o pacote de sysroot (ou preencher `ToolchainConfig.kt` para baixar) -> modo A -> Executar.
Logs: `adb logcat -s ci-native`.

## Testado / não testado
* Testado no PC (g++ no lugar do clang): hash, cache/LRU, PCH, isolamento (crash/timeout/cancelamento/limite de
  saída/stdin grande), compilar + `dlopen` + executar, compilador inexistente.
* NÃO testado: nada no Android (JNI do exec, ToolchainManager, execução do clang/lld, flags de `--target`/`--sysroot`/
  `-resource-dir`/`--ld-path` com um clang real) e o script do pacote. Espere ajustes de flags no primeiro teste real.
* Riscos conhecidos do `fork()` num app multithread: se outra thread estiver no meio de um `dlopen` na hora do
  fork, o filho pode travar (o timeout o mata). Não medido no Android.
* Um programa por vez; o código do usuário roda com as permissões do app.
