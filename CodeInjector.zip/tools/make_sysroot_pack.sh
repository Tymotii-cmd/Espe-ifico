#!/usr/bin/env bash
# Monta o pacote (sysroot + clang-resource) de UM ABI.
# Uso: tools/make_sysroot_pack.sh <NDK_ROOT> <sysroot-triple> <clang-resource-dir> <saida.zip> [ndk-rt-dir]
#   sysroot-triple:     aarch64-linux-android | arm-linux-androideabi | x86_64-linux-android
#   clang-resource-dir: lib/clang/<versão> do clang que será executado (usamos só o include/ dele)
#   ndk-rt-dir:         (opcional) <NDK>/toolchains/llvm/prebuilt/linux-x86_64/lib/clang/<v>/lib/linux
#                       => copia libclang_rt.builtins-<arch>-android.a e <arch>/libunwind.a (necessários ao link)
# Imprime sha256 e tamanho (para o ToolchainManifest).
set -euo pipefail
NDK="$1"; TRIPLE="$2"; RES="$3"; OUT="$(realpath -m "$4")"; RT="${5:-}"
SR="$NDK/toolchains/llvm/prebuilt/linux-x86_64/sysroot"
[ -d "$SR/usr/include" ] || { echo "sysroot do NDK não encontrado em $SR" >&2; exit 1; }
[ -d "$RES/include" ]   || { echo "clang-resource-dir sem include/: $RES" >&2; exit 1; }
case "$TRIPLE" in aarch64*) ARCH=aarch64;; arm*) ARCH=arm;; x86_64*) ARCH=x86_64;; i686*) ARCH=i386;; *) echo "triple desconhecido: $TRIPLE" >&2; exit 1;; esac

W="$(mktemp -d)"; trap 'rm -rf "$W"' EXIT
mkdir -p "$W/sysroot/usr/lib" "$W/clang-resource/lib/linux"
cp -a "$SR/usr/include" "$W/sysroot/usr/include"
cp -a "$SR/usr/lib/$TRIPLE" "$W/sysroot/usr/lib/$TRIPLE"     # crt*.o, libc.so, libm.so, libc++_static.a ... por API level
cp -a "$RES/include" "$W/clang-resource/include"
if [ -n "$RT" ]; then
  cp -a "$RT"/libclang_rt.builtins-"$ARCH"-android.a "$W/clang-resource/lib/linux/"
  [ -f "$RT/$ARCH/libunwind.a" ] && { mkdir -p "$W/clang-resource/lib/linux/$ARCH"; cp -a "$RT/$ARCH/libunwind.a" "$W/clang-resource/lib/linux/$ARCH/"; }
fi

rm -f "$OUT"; (cd "$W" && zip -qr -9 "$OUT" .)
echo "arquivo: $OUT"
echo "sha256:  $(sha256sum "$OUT" | cut -d' ' -f1)"
echo "tamanho: $(stat -c %s "$OUT")"
