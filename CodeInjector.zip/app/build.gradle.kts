plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.chaquopy)
}

android {
    namespace = "com.dev.codeinjector"
    compileSdk = 34
    // NDK e CMake FIXOS: o mesmo binário em qualquer máquina/CI. O workflow instala exatamente estas versões.
    ndkVersion = "26.1.10909125"
    defaultConfig {
        applicationId = "com.dev.codeinjector"
        minSdk = 26              // Chaquopy 17 exige minSdk >= 24
        targetSdk = 34
        versionCode = 2
        versionName = "2.0-python"
        ndk {
            // ARMv8 (64 bits) + ARMv7 (32 bits). Para emulador: ./gradlew -Pci.abis=arm64-v8a,armeabi-v7a,x86_64
            val abis = (findProperty("ci.abis") as String?) ?: "arm64-v8a,armeabi-v7a"
            abiFilters += abis.split(",").map { it.trim() }
        }
        externalNativeBuild {
            cmake {
                // Release SEMPRE (inclusive no APK "debug"): as flags -O3/ThinLTO ficam no CMakeLists.txt.
                arguments += listOf(
                    "-DCMAKE_BUILD_TYPE=Release",
                    "-DANDROID_PLATFORM=android-26",
                    "-DANDROID_STL=c++_static",     // sem libc++_shared.so: menos MB e sem conflito de STL
                    "-DANDROID_ARM_NEON=TRUE"       // NEON no ARMv7 (o ARMv8 já tem)
                )
            }
        }
    }
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }
    buildTypes {
        release { isMinifyEnabled = false }
        // APK debuggable deixa o Compose/ART bem mais lentos; o APK de debug continua assinado e instalável
        debug {
            isDebuggable = false
            isJniDebuggable = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging {
        // Modo A do toolchain (README_TOOLCHAIN.md): clang/lld empacotados como jniLibs/<abi>/libclang.so e liblld.so.
        // Só liga com  -Pci.clangInApk=true  (extrai as libs nativas e não faz strip nos executáveis).
        if (project.hasProperty("ci.clangInApk")) {
            jniLibs {
                useLegacyPackaging = true
                keepDebugSymbols += setOf("**/libclang.so", "**/liblld.so")
            }
        }
        resources {
            excludes += setOf(
                "META-INF/MANIFEST.MF", "META-INF/*.SF", "META-INF/*.RSA", "META-INF/*.DSA",
                "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/*.kotlin_module", "META-INF/versions/**"
            )
        }
    }
}

chaquopy {
    defaultConfig {
        // CPython embutido. 3.11 = mensagens de erro detalhadas (linha/coluna) e suporte a 32 e 64 bits.
        version = "3.11"
        // Bytecode (.pyc) usa o Python do PC de build (precisa ser 3.11). Se não houver, o build continua só com aviso.
        // Bibliotecas Python extras (instaladas no build). requests é leve; numpy/pandas deixam o APK bem maior.
        pip {
            install("requests")
            // install("numpy")
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.foundation)
    implementation(libs.androidx.material3)
    implementation(libs.kotlinx.coroutines.android)
}
