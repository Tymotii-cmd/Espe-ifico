#pragma once
#include <cstddef>
#include <cstdint>

namespace ci {

// UTF-8 -> UTF-16. `dst` precisa de >= n unidades (UTF-16 nunca excede o nº de bytes UTF-8).
// Bytes inválidos viram U+FFFD (1 por byte). `dst` pode sobrepor o FIM de `src` desde que
// dst_bytes_end >= src + n e dst + out <= src + consumido (ver file_io: decodificação in-place).
size_t utf8_to_utf16(const uint8_t* src, size_t n, char16_t* dst) noexcept;

// UTF-16 -> UTF-8. `dst` precisa de >= 3*n bytes. Surrogates soltos viram U+FFFD.
size_t utf16_to_utf8(const char16_t* src, size_t n, uint8_t* dst) noexcept;

}  // namespace ci
