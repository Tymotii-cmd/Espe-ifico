#pragma once
// Tarefa move-only com armazenamento inline (sem heap). Se a lambda for grande demais,
// o erro aparece em tempo de compilação: capture ponteiros/ids, não objetos grandes.
#include <cstddef>
#include <new>
#include <type_traits>
#include <utility>

namespace ci {

class Task {
 public:
  static constexpr size_t kInline = 56;

  Task() noexcept = default;

  template <class F, class D = std::decay_t<F>,
            class = std::enable_if_t<!std::is_same_v<D, Task> && std::is_invocable_r_v<void, D&>>>
  Task(F&& f) {  // NOLINT(google-explicit-constructor)
    static_assert(sizeof(D) <= kInline, "Task: captura grande demais (limite 56 bytes)");
    static_assert(alignof(D) <= alignof(std::max_align_t), "Task: alinhamento excessivo");
    static_assert(std::is_nothrow_move_constructible_v<D>, "Task: callable precisa ser nothrow-movable");
    ::new (static_cast<void*>(buf_)) D(std::forward<F>(f));
    vt_ = &kVTable<D>;
  }

  Task(Task&& o) noexcept { move_from(o); }
  Task& operator=(Task&& o) noexcept {
    if (this != &o) {
      reset();
      move_from(o);
    }
    return *this;
  }
  Task(const Task&) = delete;
  Task& operator=(const Task&) = delete;
  ~Task() { reset(); }

  explicit operator bool() const noexcept { return vt_ != nullptr; }
  void operator()() { vt_->invoke(buf_); }

 private:
  struct VTable {
    void (*invoke)(void*);
    void (*relocate)(void* dst, void* src) noexcept;
    void (*destroy)(void*) noexcept;
  };
  template <class D>
  static inline constexpr VTable kVTable = {
      [](void* p) { (*static_cast<D*>(p))(); },
      [](void* d, void* s) noexcept {
        ::new (d) D(std::move(*static_cast<D*>(s)));
        static_cast<D*>(s)->~D();
      },
      [](void* p) noexcept { static_cast<D*>(p)->~D(); }};

  void move_from(Task& o) noexcept {
    if (o.vt_) {
      o.vt_->relocate(buf_, o.buf_);
      vt_ = o.vt_;
      o.vt_ = nullptr;
    }
  }
  void reset() noexcept {
    if (vt_) {
      vt_->destroy(buf_);
      vt_ = nullptr;
    }
  }

  alignas(std::max_align_t) unsigned char buf_[kInline];
  const VTable* vt_ = nullptr;
};

}  // namespace ci
