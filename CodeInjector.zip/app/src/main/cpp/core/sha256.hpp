#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>

namespace ci {

class Sha256 {
 public:
  Sha256();
  void update(const void* data, size_t n);
  std::array<uint8_t, 32> finish();

 private:
  void block(const uint8_t* p);
  uint32_t h_[8];
  uint8_t buf_[64];
  size_t bufLen_ = 0;
  uint64_t total_ = 0;
};

std::string to_hex(const std::array<uint8_t, 32>& d);
inline std::string sha256_hex(std::string_view s) {
  Sha256 h;
  h.update(s.data(), s.size());
  return to_hex(h.finish());
}

}  // namespace ci
