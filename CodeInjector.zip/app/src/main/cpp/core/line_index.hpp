#pragma once
#include <cstddef>
#include <cstdint>
#include <vector>

namespace ci {

// Offsets de início de cada linha (separador '\n'). O vetor mantém capacidade entre usos.
class LineIndex {
 public:
  void build(const char16_t* text, size_t n) {
    starts_.clear();
    starts_.push_back(0);
    for (size_t i = 0; i < n; ++i)
      if (text[i] == u'\n') starts_.push_back(static_cast<uint32_t>(i + 1));
    n_ = n;
  }
  size_t count() const { return starts_.size(); }
  size_t start(size_t line) const { return starts_[line]; }
  size_t end(size_t line) const { return line + 1 < starts_.size() ? starts_[line + 1] - 1 : n_; }

 private:
  std::vector<uint32_t> starts_;
  size_t n_ = 0;
};

}  // namespace ci
