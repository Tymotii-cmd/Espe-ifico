#pragma once
#include <atomic>
#include <condition_variable>
#include <mutex>
#include <thread>
#include <vector>

#include "core/mpmc_queue.hpp"
#include "core/task.hpp"

namespace ci {

struct PoolHooks {  // chamados dentro da própria thread (ex.: attach/detach da JVM)
  void (*on_start)(void*) = nullptr;
  void (*on_exit)(void*) = nullptr;
  void* user = nullptr;
};

// Pool fixo de workers. Caminho quente (submit/pop) é lock-free; o mutex só é usado
// para estacionar workers ociosos (sem busy-wait: não gasta bateria).
class ThreadPool {
 public:
  using Hooks = PoolHooks;

  explicit ThreadPool(unsigned threads, size_t queueCapacity = 1024, Hooks hooks = {});
  ~ThreadPool();
  ThreadPool(const ThreadPool&) = delete;
  ThreadPool& operator=(const ThreadPool&) = delete;

  // false se a fila estiver cheia (a tarefa continua com o chamador).
  bool submit(Task&& t) noexcept;

  // Executa o que já está na fila e encerra os workers. Idempotente; chame só do dono.
  void stop();

  unsigned size() const { return static_cast<unsigned>(threads_.size()); }

 private:
  void worker();

  MpmcQueue<Task> q_;
  std::vector<std::thread> threads_;
  std::mutex mu_;
  std::condition_variable cv_;
  std::atomic<int> sleepers_{0};
  std::atomic<bool> stop_{false};
  Hooks hooks_;
};

}  // namespace ci
