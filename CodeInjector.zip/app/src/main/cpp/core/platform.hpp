#pragma once
#include <cstddef>
#include <cstdint>

#define CI_LIKELY(x) __builtin_expect(!!(x), 1)
#define CI_UNLIKELY(x) __builtin_expect(!!(x), 0)
#define CI_EXPORT __attribute__((visibility("default")))

namespace ci {
inline constexpr size_t kCacheLine = 64;
}  // namespace ci
