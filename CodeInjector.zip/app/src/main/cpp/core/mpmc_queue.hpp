#pragma once
// Fila MPMC limitada, lock-free (algoritmo de Dmitry Vyukov).
// Sem alocação depois da construção. T precisa ser default-constructible e movível.
#include <atomic>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <utility>

#include "core/platform.hpp"

namespace ci {

template <class T>
class MpmcQueue {
  struct Cell {
    std::atomic<size_t> seq;
    T data;
  };
  struct Padded {  // padding manual: evita over-aligned new (frágil em libc++/Android)
    std::atomic<size_t> v{0};
    char pad[kCacheLine - sizeof(std::atomic<size_t>)];
  };

 public:
  explicit MpmcQueue(size_t capacity)
      : mask_(std::bit_ceil(capacity < 2 ? size_t{2} : capacity) - 1), cells_(new Cell[mask_ + 1]) {
    for (size_t i = 0; i <= mask_; ++i) cells_[i].seq.store(i, std::memory_order_relaxed);
  }
  MpmcQueue(const MpmcQueue&) = delete;
  MpmcQueue& operator=(const MpmcQueue&) = delete;

  size_t capacity() const { return mask_ + 1; }

  // Se retornar false, `v` NÃO foi consumido (pode tentar de novo).
  bool try_push(T&& v) {
    Cell* c;
    size_t pos = enq_.v.load(std::memory_order_relaxed);
    for (;;) {
      c = &cells_[pos & mask_];
      const size_t seq = c->seq.load(std::memory_order_acquire);
      const auto dif = static_cast<std::intptr_t>(seq) - static_cast<std::intptr_t>(pos);
      if (dif == 0) {
        if (enq_.v.compare_exchange_weak(pos, pos + 1, std::memory_order_relaxed)) break;
      } else if (dif < 0) {
        return false;  // cheia
      } else {
        pos = enq_.v.load(std::memory_order_relaxed);
      }
    }
    c->data = std::move(v);
    c->seq.store(pos + 1, std::memory_order_release);
    return true;
  }

  bool try_pop(T& out) {
    Cell* c;
    size_t pos = deq_.v.load(std::memory_order_relaxed);
    for (;;) {
      c = &cells_[pos & mask_];
      const size_t seq = c->seq.load(std::memory_order_acquire);
      const auto dif = static_cast<std::intptr_t>(seq) - static_cast<std::intptr_t>(pos + 1);
      if (dif == 0) {
        if (deq_.v.compare_exchange_weak(pos, pos + 1, std::memory_order_relaxed)) break;
      } else if (dif < 0) {
        return false;  // vazia
      } else {
        pos = deq_.v.load(std::memory_order_relaxed);
      }
    }
    out = std::move(c->data);
    c->seq.store(pos + mask_ + 1, std::memory_order_release);
    return true;
  }

 private:
  const size_t mask_;
  std::unique_ptr<Cell[]> cells_;
  Padded enq_;
  Padded deq_;
};

}  // namespace ci
