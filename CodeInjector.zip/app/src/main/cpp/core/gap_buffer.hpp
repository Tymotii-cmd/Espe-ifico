#pragma once
// Buffer de texto UTF-16 com "gap": inserções/remoções perto do cursor são O(tamanho da edição).
#include <algorithm>
#include <cstddef>
#include <cstring>
#include <memory>

namespace ci {

class GapBuffer {
 public:
  explicit GapBuffer(size_t initialCapacity = 4096)
      : cap_(initialCapacity < 16 ? 16 : initialCapacity), buf_(new char16_t[cap_]), gs_(0), ge_(cap_) {}

  size_t size() const { return cap_ - (ge_ - gs_); }
  size_t capacity() const { return cap_; }
  char16_t operator[](size_t i) const { return buf_[i < gs_ ? i : i + (ge_ - gs_)]; }

  void insert(size_t pos, const char16_t* s, size_t n) {
    pos = std::min(pos, size());
    if (n == 0) return;
    reserve_gap(n);
    move_gap(pos);
    std::memcpy(buf_.get() + gs_, s, n * sizeof(char16_t));
    gs_ += n;
  }

  void erase(size_t pos, size_t n) {
    const size_t sz = size();
    if (pos >= sz) return;
    n = std::min(n, sz - pos);
    move_gap(pos);
    ge_ += n;
  }

  void copy_to(size_t pos, size_t n, char16_t* dst) const {
    const size_t sz = size();
    if (pos >= sz) return;
    n = std::min(n, sz - pos);
    if (pos < gs_) {
      const size_t a = std::min(n, gs_ - pos);
      std::memcpy(dst, buf_.get() + pos, a * sizeof(char16_t));
      if (n > a) std::memcpy(dst + a, buf_.get() + ge_, (n - a) * sizeof(char16_t));
    } else {
      std::memcpy(dst, buf_.get() + ge_ + (pos - gs_), n * sizeof(char16_t));
    }
  }

 private:
  void move_gap(size_t pos) {
    if (pos < gs_) {
      const size_t k = gs_ - pos;
      std::memmove(buf_.get() + ge_ - k, buf_.get() + pos, k * sizeof(char16_t));
      gs_ -= k;
      ge_ -= k;
    } else if (pos > gs_) {
      const size_t k = pos - gs_;
      std::memmove(buf_.get() + gs_, buf_.get() + ge_, k * sizeof(char16_t));
      gs_ += k;
      ge_ += k;
    }
  }

  void reserve_gap(size_t n) {
    if (ge_ - gs_ >= n) return;
    const size_t used = size();
    const size_t newCap = std::max(cap_ + cap_ / 2, used + n + 1024);
    std::unique_ptr<char16_t[]> nb(new char16_t[newCap]);
    std::memcpy(nb.get(), buf_.get(), gs_ * sizeof(char16_t));
    const size_t tail = cap_ - ge_;
    std::memcpy(nb.get() + newCap - tail, buf_.get() + ge_, tail * sizeof(char16_t));
    buf_ = std::move(nb);
    ge_ = newCap - tail;
    cap_ = newCap;
  }

  size_t cap_;
  std::unique_ptr<char16_t[]> buf_;
  size_t gs_, ge_;
};

}  // namespace ci
