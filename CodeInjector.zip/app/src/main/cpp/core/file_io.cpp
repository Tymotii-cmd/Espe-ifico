#include "core/file_io.hpp"

#include <sys/stat.h>
#include <unistd.h>

#include <cerrno>
#include <cstring>
#include <vector>

#include "core/utf.hpp"

namespace ci {
namespace {

constexpr size_t kBinaryProbe = 8000;

// Decodifica `n` bytes em `src` para `dst`, tratando BOM e arquivo binário.
int64_t finish(const uint8_t* src, size_t n, char16_t* dst) noexcept {
  if (n >= 3 && src[0] == 0xEF && src[1] == 0xBB && src[2] == 0xBF) {
    src += 3;
    n -= 3;
  }
  if (std::memchr(src, 0, n < kBinaryProbe ? n : kBinaryProbe)) return kErrBinary;
  return static_cast<int64_t>(utf8_to_utf16(src, n, dst));
}

// Caminho lento (pipes/sockets de provedores SAF): lê tudo num vetor temporário.
int64_t read_streaming(int fd, char16_t* dst, size_t capChars, size_t maxBytes) noexcept {
  std::vector<uint8_t> tmp;
  tmp.reserve(64 * 1024);
  uint8_t chunk[16384];
  for (;;) {
    const ssize_t r = ::read(fd, chunk, sizeof chunk);
    if (r < 0) {
      if (errno == EINTR) continue;
      return kErrIo;
    }
    if (r == 0) break;
    if (tmp.size() + static_cast<size_t>(r) > maxBytes) return kErrTooLarge;
    tmp.insert(tmp.end(), chunk, chunk + r);
  }
  if (tmp.size() > capChars) return kErrCapacity;
  return finish(tmp.data(), tmp.size(), dst);
}

}  // namespace

int64_t read_fd_utf16(int fd, char16_t* dst, size_t capChars, size_t maxBytes) noexcept {
  struct stat st;
  if (::fstat(fd, &st) != 0) return kErrIo;
  if (!S_ISREG(st.st_mode) || st.st_size <= 0) return read_streaming(fd, dst, capChars, maxBytes);

  const size_t size = static_cast<size_t>(st.st_size);
  if (size > maxBytes) return kErrTooLarge;
  if (size > capChars) return kErrCapacity;

  // Bytes crus no FIM do buffer; a decodificação (que só avança mais devagar que a leitura)
  // nunca alcança bytes ainda não lidos: 2*out <= 2*i <= (2*cap - size) + i, pois i <= size <= cap.
  uint8_t* base = reinterpret_cast<uint8_t*>(dst) + (2 * capChars - size);
  size_t got = 0;
  while (got < size) {
    const ssize_t r = ::pread(fd, base + got, size - got, static_cast<off_t>(got));
    if (r < 0) {
      if (errno == EINTR) continue;
      return kErrIo;
    }
    if (r == 0) break;  // arquivo encolheu durante a leitura: usa o que veio
    got += static_cast<size_t>(r);
  }
  return finish(base, got, dst);
}

int64_t write_fd_utf16(int fd, const char16_t* src, size_t n) noexcept {
  constexpr size_t kUnits = 16384;
  uint8_t buf[kUnits * 3 + 8];
  int64_t total = 0;
  size_t i = 0;
  while (i < n) {
    size_t take = n - i < kUnits ? n - i : kUnits;
    // não corta um par surrogate ao meio
    if (i + take < n && src[i + take - 1] >= 0xD800 && src[i + take - 1] <= 0xDBFF) ++take;
    const size_t bytes = utf16_to_utf8(src + i, take, buf);
    size_t off = 0;
    while (off < bytes) {
      const ssize_t w = ::write(fd, buf + off, bytes - off);
      if (w < 0) {
        if (errno == EINTR) continue;
        return kErrIo;
      }
      off += static_cast<size_t>(w);
    }
    total += static_cast<int64_t>(bytes);
    i += take;
  }
  return total;
}

}  // namespace ci
