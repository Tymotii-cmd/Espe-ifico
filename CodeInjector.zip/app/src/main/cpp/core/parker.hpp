#pragma once
// Estaciona uma thread até alguém chamar notify(). Sem perda de wake-up:
// o flag é escrito sob o mesmo mutex que o waiter usa no predicado.
#include <chrono>
#include <condition_variable>
#include <mutex>

namespace ci {

class Parker {
 public:
  void notify() {
    {
      std::lock_guard<std::mutex> lk(m_);
      flag_ = true;
    }
    cv_.notify_one();
  }
  void wait() {
    std::unique_lock<std::mutex> lk(m_);
    cv_.wait(lk, [&] { return flag_; });
    flag_ = false;
  }
  // true se foi notificado, false se estourou o tempo.
  bool wait_for(std::chrono::milliseconds d) {
    std::unique_lock<std::mutex> lk(m_);
    const bool r = cv_.wait_for(lk, d, [&] { return flag_; });
    flag_ = false;
    return r;
  }

 private:
  std::mutex m_;
  std::condition_variable cv_;
  bool flag_ = false;
};

}  // namespace ci
