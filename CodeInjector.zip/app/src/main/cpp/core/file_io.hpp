#pragma once
#include <cstddef>
#include <cstdint>

namespace ci {

inline constexpr int64_t kErrIo = -1;        // falha de leitura/escrita
inline constexpr int64_t kErrBinary = -2;    // NUL nos primeiros 8000 bytes
inline constexpr int64_t kErrTooLarge = -3;  // acima de maxBytes
inline constexpr int64_t kErrCapacity = -4;  // dst pequeno: refaça com capChars >= tamanho em bytes

// Lê o arquivo (fd emprestado, não é fechado) e decodifica UTF-8 -> UTF-16 DIRETO em `dst`.
// Para arquivos regulares o read() cai no fim do próprio `dst` e é decodificado in-place:
// zero cópias intermediárias, zero alocações, e sem mmap (que daria SIGBUS se o arquivo encolhesse).
// `dst` precisa ter 2 bytes de alinhamento e capChars >= tamanho do arquivo em bytes.
// Retorna nº de unidades char16_t escritas, ou um dos kErr*.
int64_t read_fd_utf16(int fd, char16_t* dst, size_t capChars, size_t maxBytes) noexcept;

// Codifica UTF-16 -> UTF-8 em blocos de 48 KB e grava no fd. Retorna bytes gravados ou kErrIo.
int64_t write_fd_utf16(int fd, const char16_t* src, size_t n) noexcept;

}  // namespace ci
