#include "core/thread_pool.hpp"

#include <pthread.h>

namespace ci {

ThreadPool::ThreadPool(unsigned threads, size_t queueCapacity, Hooks hooks)
    : q_(queueCapacity), hooks_(hooks) {
  if (threads == 0) threads = 1;
  threads_.reserve(threads);
  for (unsigned i = 0; i < threads; ++i) threads_.emplace_back([this] { worker(); });
}

ThreadPool::~ThreadPool() { stop(); }

bool ThreadPool::submit(Task&& t) noexcept {
  if (!q_.try_push(std::move(t))) return false;
  // Dekker com o worker: ou ele vê a tarefa ao re-checar a fila, ou vemos sleepers_ > 0.
  std::atomic_thread_fence(std::memory_order_seq_cst);
  if (sleepers_.load(std::memory_order_relaxed) > 0) {
    { std::lock_guard<std::mutex> lk(mu_); }  // garante que o worker já está em wait()
    cv_.notify_one();
  }
  return true;
}

void ThreadPool::stop() {
  bool expected = false;
  if (!stop_.compare_exchange_strong(expected, true)) return;
  { std::lock_guard<std::mutex> lk(mu_); }
  cv_.notify_all();
  for (auto& t : threads_) t.join();
  threads_.clear();
}

void ThreadPool::worker() {
  pthread_setname_np(pthread_self(), "ci-worker");
  if (hooks_.on_start) hooks_.on_start(hooks_.user);
  Task t;
  for (;;) {
    if (q_.try_pop(t)) {
      t();
      t = Task{};
      continue;
    }
    if (stop_.load(std::memory_order_acquire)) break;  // fila vazia + stop => acabou
    std::unique_lock<std::mutex> lk(mu_);
    sleepers_.fetch_add(1, std::memory_order_seq_cst);
    std::atomic_thread_fence(std::memory_order_seq_cst);
    if (q_.try_pop(t)) {
      sleepers_.fetch_sub(1, std::memory_order_relaxed);
      lk.unlock();
      t();
      t = Task{};
      continue;
    }
    if (stop_.load(std::memory_order_acquire)) {
      sleepers_.fetch_sub(1, std::memory_order_relaxed);
      break;
    }
    cv_.wait(lk);
    sleepers_.fetch_sub(1, std::memory_order_relaxed);
  }
  if (hooks_.on_exit) hooks_.on_exit(hooks_.user);
}

}  // namespace ci
