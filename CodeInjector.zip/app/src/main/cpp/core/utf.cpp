#include "core/utf.hpp"

#include <cstring>

namespace ci {
namespace {
inline bool cont(uint8_t b) { return (b & 0xC0) == 0x80; }
}  // namespace

size_t utf8_to_utf16(const uint8_t* s, size_t n, char16_t* d) noexcept {
  size_t i = 0, o = 0;
  while (i < n) {
    // Caminho rápido ASCII, 8 bytes por vez. Lê tudo para um registrador ANTES de escrever
    // (necessário para a decodificação in-place).
    while (i + 8 <= n) {
      uint64_t w;
      std::memcpy(&w, s + i, 8);
      if (w & 0x8080808080808080ull) break;
      char16_t tmp[8];
      for (int k = 0; k < 8; ++k) tmp[k] = static_cast<char16_t>((w >> (8 * k)) & 0xFF);  // little-endian
      std::memcpy(d + o, tmp, sizeof tmp);
      i += 8;
      o += 8;
    }
    if (i >= n) break;
    const uint8_t b = s[i];
    if (b < 0x80) {
      d[o++] = b;
      ++i;
      continue;
    }
    if (b >= 0xC2 && b <= 0xDF) {
      if (i + 1 < n && cont(s[i + 1])) {
        d[o++] = static_cast<char16_t>(((b & 0x1F) << 6) | (s[i + 1] & 0x3F));
        i += 2;
        continue;
      }
    } else if (b >= 0xE0 && b <= 0xEF) {
      if (i + 2 < n && cont(s[i + 1]) && cont(s[i + 2])) {
        const uint32_t cp = ((b & 0x0Fu) << 12) | ((s[i + 1] & 0x3Fu) << 6) | (s[i + 2] & 0x3Fu);
        if (cp >= 0x800 && (cp < 0xD800 || cp > 0xDFFF)) {
          d[o++] = static_cast<char16_t>(cp);
          i += 3;
          continue;
        }
      }
    } else if (b >= 0xF0 && b <= 0xF4) {
      if (i + 3 < n && cont(s[i + 1]) && cont(s[i + 2]) && cont(s[i + 3])) {
        uint32_t cp = ((b & 0x07u) << 18) | ((s[i + 1] & 0x3Fu) << 12) | ((s[i + 2] & 0x3Fu) << 6) | (s[i + 3] & 0x3Fu);
        if (cp >= 0x10000 && cp <= 0x10FFFF) {
          cp -= 0x10000;
          d[o++] = static_cast<char16_t>(0xD800 + (cp >> 10));
          d[o++] = static_cast<char16_t>(0xDC00 + (cp & 0x3FF));
          i += 4;
          continue;
        }
      }
    }
    d[o++] = 0xFFFD;
    ++i;
  }
  return o;
}

size_t utf16_to_utf8(const char16_t* s, size_t n, uint8_t* d) noexcept {
  size_t o = 0;
  for (size_t i = 0; i < n; ++i) {
    const uint32_t c = s[i];
    if (c < 0x80) {
      d[o++] = static_cast<uint8_t>(c);
    } else if (c < 0x800) {
      d[o++] = static_cast<uint8_t>(0xC0 | (c >> 6));
      d[o++] = static_cast<uint8_t>(0x80 | (c & 0x3F));
    } else if (c >= 0xD800 && c <= 0xDBFF && i + 1 < n && s[i + 1] >= 0xDC00 && s[i + 1] <= 0xDFFF) {
      const uint32_t cp = 0x10000 + ((c - 0xD800) << 10) + (s[i + 1] - 0xDC00u);
      d[o++] = static_cast<uint8_t>(0xF0 | (cp >> 18));
      d[o++] = static_cast<uint8_t>(0x80 | ((cp >> 12) & 0x3F));
      d[o++] = static_cast<uint8_t>(0x80 | ((cp >> 6) & 0x3F));
      d[o++] = static_cast<uint8_t>(0x80 | (cp & 0x3F));
      ++i;
    } else if (c >= 0xD800 && c <= 0xDFFF) {
      d[o++] = 0xEF; d[o++] = 0xBF; d[o++] = 0xBD;
    } else {
      d[o++] = static_cast<uint8_t>(0xE0 | (c >> 12));
      d[o++] = static_cast<uint8_t>(0x80 | ((c >> 6) & 0x3F));
      d[o++] = static_cast<uint8_t>(0x80 | (c & 0x3F));
    }
  }
  return o;
}

}  // namespace ci
