// Ponte JNI. Princípios:
//  * Dados grandes cruzam a ponte só como java.nio direct buffers (GetDirectBufferAddress):
//    nada de GetArrayElements/GetStringChars, nenhuma cópia ou alocação por chamada.
//  * RegisterNatives no JNI_OnLoad (sem lookup por nome de símbolo) + visibilidade hidden.
//  * Threads do pool fazem attach na JVM uma vez e só detach ao sair.
#include <android/log.h>
#include <android/native_window_jni.h>
#include <dlfcn.h>
#include <unistd.h>
#include <jni.h>

#include <algorithm>
#include <atomic>
#include <filesystem>
#include <cstring>
#include <memory>
#include <thread>

#include "core/file_io.hpp"
#include "core/platform.hpp"
#include "core/thread_pool.hpp"
#include "core/utf.hpp"
#include "exec/backends.hpp"
#include "exec/pipeline.hpp"
#include "render/renderer.hpp"
#include "scene/snapshot.hpp"
#include "syntax/py_lexer.hpp"

#define LOG_TAG "ci-native"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace ci {
namespace {

constexpr const char* kClassName = "com/dev/codeinjector/nativecore/NativeCore";
constexpr size_t kMaxIssues = 1024;

JavaVM* g_vm = nullptr;

JNIEnv* current_env() {
  JNIEnv* env = nullptr;
  if (g_vm && g_vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) == JNI_OK) return env;
  return nullptr;
}

void hook_start(void*) {
  JNIEnv* env = nullptr;
  g_vm->AttachCurrentThread(&env, nullptr);
}
void hook_exit(void*) { g_vm->DetachCurrentThread(); }

struct Engine {
  Engine(unsigned threads, JNIEnv* env, jobject listener)
      : pool(threads + 4),
        workers(threads, 256, PoolHooks{hook_start, hook_exit, nullptr}),
        renderer(std::make_unique<Renderer>(pool)) {
    this->listener = env->NewGlobalRef(listener);
    jclass cls = env->GetObjectClass(listener);
    onDone = env->GetMethodID(cls, "onAnalysisDone", "(JIIZ)V");
    env->DeleteLocalRef(cls);
  }

  ~Engine() {
    workers.stop();   // drena as análises pendentes (podem postar no renderer)
    renderer.reset(); // depois o renderer; devolve snapshots ao pool, que ainda existe
    if (JNIEnv* env = current_env()) env->DeleteGlobalRef(listener);
  }

  void bump_latest(uint64_t r) {
    uint64_t cur = latest.load(std::memory_order_relaxed);
    while (r > cur && !latest.compare_exchange_weak(cur, r, std::memory_order_relaxed)) {}
  }

  // Layout do buffer de saída (int32): [0]=nSpans [1]=nIssues [2]=truncado [3]=reservado,
  // depois nIssues*8 ints (struct Issue) e nSpans*3 ints (struct Span).
  static void serialize(const Snapshot& s, int32_t& ns, int32_t& ni, bool& trunc) {
    ns = ni = 0;
    trunc = false;
    int32_t* o = s.out;
    const size_t cap = s.outCapInts;
    if (!o || cap < 4) { trunc = true; return; }
    const auto& sp = s.lex.spans;
    const auto& is = s.lex.issues;
    const size_t nIssues = std::min({is.size(), (cap - 4) / 8, kMaxIssues});
    const size_t room = cap - 4 - nIssues * 8;
    const size_t nSpans = std::min(sp.size(), room / 3);
    std::memcpy(o + 4, is.data(), nIssues * sizeof(syntax::Issue));
    std::memcpy(o + 4 + nIssues * 8, sp.data(), nSpans * sizeof(syntax::Span));
    o[0] = static_cast<int32_t>(nSpans);
    o[1] = static_cast<int32_t>(nIssues);
    trunc = nSpans < sp.size() || nIssues < is.size();
    o[2] = trunc;
    o[3] = 0;
    ns = static_cast<int32_t>(nSpans);
    ni = static_cast<int32_t>(nIssues);
  }

  void run_analysis(Snapshot* s) {
    JNIEnv* env = current_env();
    const uint64_t req = s->req;
    const bool stale = req < latest.load(std::memory_order_relaxed);  // chegou outra mais nova: pula o trabalho
    int32_t ns = -1, ni = 0;
    bool trunc = false;
    bool publish = false;
    if (!stale) {
      syntax::lex_python(s->text.data(), s->text.size(), s->lex);
      serialize(*s, ns, ni, trunc);
      if (s->publish) {
        s->lines.build(s->text.data(), s->text.size());
        publish = true;
      }
    }
    jobject outRef = static_cast<jobject>(s->outRef);
    s->outRef = nullptr;
    if (publish) renderer->set_scene(s);  // o renderer devolve ao pool quando trocar de cena
    else pool.release(s);

    if (env) {
      env->CallVoidMethod(listener, onDone, static_cast<jlong>(req), static_cast<jint>(ns), static_cast<jint>(ni),
                          static_cast<jboolean>(trunc));
      if (env->ExceptionCheck()) env->ExceptionClear();
      if (outRef) env->DeleteGlobalRef(outRef);
    }
  }

  SnapshotPool pool;
  ThreadPool workers;
  std::unique_ptr<Renderer> renderer;
  jobject listener = nullptr;
  jmethodID onDone = nullptr;
  std::atomic<uint64_t> latest{0};
};

std::atomic<Engine*> g_engine{nullptr};

// Valida e devolve o ponteiro de um direct buffer (nullptr se inválido).
void* direct_ptr(JNIEnv* env, jobject buf, jlong minBytes, size_t align) {
  if (!buf) return nullptr;
  void* p = env->GetDirectBufferAddress(buf);
  const jlong cap = env->GetDirectBufferCapacity(buf);
  if (!p || cap < minBytes || (reinterpret_cast<uintptr_t>(p) & (align - 1)) != 0) return nullptr;
  return p;
}

// ---------------------------------------------------------------- métodos nativos
void nInit(JNIEnv* env, jclass, jint threads, jobject listener) {
  if (g_engine.load()) return;  // idempotente
  unsigned n = threads > 0 ? static_cast<unsigned>(threads) : std::max(1u, std::min(4u, std::thread::hardware_concurrency() - 1));
  g_engine.store(new Engine(n, env, listener));
}

void nShutdown(JNIEnv*, jclass) { delete g_engine.exchange(nullptr); }

jlong nReadFile(JNIEnv* env, jclass, jint fd, jobject dst, jint capChars, jint maxBytes) {
  if (capChars < 0 || maxBytes < 0) return kErrIo;
  auto* p = static_cast<char16_t*>(direct_ptr(env, dst, static_cast<jlong>(capChars) * 2, alignof(char16_t)));
  if (!p) return kErrIo;
  return read_fd_utf16(fd, p, static_cast<size_t>(capChars), static_cast<size_t>(maxBytes));
}

jlong nWriteFile(JNIEnv* env, jclass, jint fd, jobject src, jint lenChars) {
  if (lenChars < 0) return kErrIo;
  auto* p = static_cast<const char16_t*>(direct_ptr(env, src, static_cast<jlong>(lenChars) * 2, alignof(char16_t)));
  if (!p && lenChars > 0) return kErrIo;
  return write_fd_utf16(fd, p, static_cast<size_t>(lenChars));
}

jboolean nAnalyzeAsync(JNIEnv* env, jclass, jobject src, jint lenChars, jobject out, jlong reqId, jboolean publish) {
  Engine* e = g_engine.load();
  if (!e || lenChars < 0) return JNI_FALSE;
  auto* sp = static_cast<const char16_t*>(direct_ptr(env, src, static_cast<jlong>(lenChars) * 2, alignof(char16_t)));
  auto* op = static_cast<int32_t*>(direct_ptr(env, out, 16, alignof(int32_t)));
  if ((!sp && lenChars > 0) || !op) return JNI_FALSE;

  Snapshot* s = e->pool.acquire();
  if (!s) return JNI_FALSE;  // sem slot livre: o chamador tenta de novo na próxima edição
  // Única cópia do caminho: snapshot imutável para a thread de análise (evita data race com o
  // buffer que o Kotlin pode reescrever assim que esta chamada retorna). Sem realocar em regime.
  s->text.assign(sp, sp + lenChars);
  s->req = static_cast<uint64_t>(reqId);
  s->out = op;
  s->outCapInts = static_cast<size_t>(env->GetDirectBufferCapacity(out)) / 4;
  s->outRef = env->NewGlobalRef(out);  // mantém o buffer vivo até o worker terminar
  s->publish = publish != JNI_FALSE;
  e->bump_latest(s->req);

  if (!e->workers.submit(Task([e, s] { e->run_analysis(s); }))) {
    env->DeleteGlobalRef(static_cast<jobject>(s->outRef));
    e->pool.release(s);
    return JNI_FALSE;
  }
  return JNI_TRUE;
}

void nSurfaceCreated(JNIEnv* env, jclass, jobject surface) {
  Engine* e = g_engine.load();
  if (!e || !surface) return;
  if (ANativeWindow* w = ANativeWindow_fromSurface(env, surface)) e->renderer->surface_created(w);
}
void nSurfaceChanged(JNIEnv*, jclass, jint w, jint h) {
  if (Engine* e = g_engine.load()) e->renderer->surface_changed(w, h);
}
void nSurfaceDestroyed(JNIEnv*, jclass) {
  if (Engine* e = g_engine.load()) e->renderer->surface_destroyed();
}
void nSetPaused(JNIEnv*, jclass, jboolean p) {
  if (Engine* e = g_engine.load()) e->renderer->set_paused(p != JNI_FALSE);
}
void nSetScroll(JNIEnv*, jclass, jfloat y) {
  if (Engine* e = g_engine.load()) e->renderer->set_scroll(y);
}
void nRequestFrame(JNIEnv*, jclass) {
  if (Engine* e = g_engine.load()) e->renderer->request_frame();
}

void nSetAtlas(JNIEnv* env, jclass, jobject pixels, jint w, jint h, jint stride, jint cols, jint rows, jint cellW, jint cellH) {
  Engine* e = g_engine.load();
  if (!e || w <= 0 || h <= 0 || stride < w || cols <= 0 || cellW <= 0 || cellH <= 0) return;
  const jlong need = static_cast<jlong>(stride) * h;
  auto* p = static_cast<const uint8_t*>(direct_ptr(env, pixels, need, 1));
  if (!p) return;
  auto a = std::make_unique<AtlasData>();
  a->info.w = w; a->info.h = h; a->info.cols = cols; a->info.rows = rows; a->info.cellW = cellW; a->info.cellH = cellH;
  a->stride = stride;
  a->pixels.assign(p, p + need);  // cópia única, rara (só ao (re)criar o atlas)
  e->renderer->set_atlas(std::move(a));
}


// ---------------------------------------------------------------- compilar + executar (toolchain baixado)
std::string to_utf8(JNIEnv* env, jstring js) {
  if (!js) return {};
  const jsize n = env->GetStringLength(js);
  const jchar* c = env->GetStringChars(js, nullptr);
  std::string out(static_cast<size_t>(n) * 3, '\0');
  out.resize(utf16_to_utf8(reinterpret_cast<const char16_t*>(c), static_cast<size_t>(n), reinterpret_cast<uint8_t*>(out.data())));
  env->ReleaseStringChars(js, c);
  return out;
}

#if defined(__aarch64__)
constexpr const char* kTriple = "aarch64-linux-android26";
#elif defined(__arm__)
constexpr const char* kTriple = "armv7a-linux-androideabi26";
#elif defined(__x86_64__)
constexpr const char* kTriple = "x86_64-linux-android26";
#else
constexpr const char* kTriple = "i686-linux-android26";
#endif

enum ExecStatus : jint { kOk = 0, kCompileError = 1, kTimeout = 2, kCrashed = 3, kCanceled = 4, kNoToolchain = 5, kInternal = 6 };

struct ExecEngine {
  using ClangMain = int (*)(int, const char* const*);

  ExecEngine(JNIEnv* env, jobject l, const std::string& tcDir, const std::string& clangPath, const std::string& ldPath,
             const std::string& cacheDir, const std::string& workDir, const std::string& id, std::string pch)
      : pool(1, 16, PoolHooks{hook_start, hook_exit, nullptr}), pchText(std::move(pch)) {
    listener = env->NewGlobalRef(l);
    jclass cls = env->GetObjectClass(l);
    onDone = env->GetMethodID(cls, "onExecDone", "(JIIZJJLjava/lang/String;)V");
    env->DeleteLocalRef(cls);

    BuildConfig cfg;
    cfg.cacheDir = cacheDir;
    cfg.workDir = workDir;
    cfg.toolchainId = id;
    cfg.compileFlags = {std::string("--target=") + kTriple, "--sysroot=" + tcDir + "/sysroot", "-std=c++20", "-O1", "-fPIC", "-pipe"};
    cfg.linkFlags = {"-shared", "-fuse-ld=lld", "-static-libstdc++", "-Wl,-z,max-page-size=16384"};

    if (!clangPath.empty()) {
      // Modo EXECUTÁVEL: clang e ld.lld rodam como processos (exec). Exige poder dar exec nesses arquivos
      // (nativeLibraryDir do APK, ou targetSdk <= 28 para arquivos em filesDir).
      if (access(clangPath.c_str(), X_OK) != 0 || access(ldPath.c_str(), X_OK) != 0) {
        LOGE("toolchain: sem permissão de execução em %s / %s", clangPath.c_str(), ldPath.c_str());
        return;
      }
      // 1) O driver deduz o modo C++ pelo NOME do executável ("clang++"); aqui ele se chama libclang.so.
      //    Sem isto o link não traria libc++.
      cfg.compileFlags.push_back("--driver-mode=g++");
      // 2) O lld é multi-chamada: escolhe o "sabor" pelo nome (ld.lld). Como liblld.so não serve, criamos um
      //    symlink ld.lld -> liblld.so em workDir (o exec segue o link; argv[0] continua "ld.lld").
      std::string ld = ldPath;
      if (std::filesystem::path(ldPath).filename() != "ld.lld") {
        std::error_code ec;
        std::filesystem::create_directories(workDir, ec);
        const std::string link = workDir + "/ld.lld";
        std::filesystem::remove(link, ec);
        std::filesystem::create_symlink(ldPath, link, ec);
        if (ec) { LOGE("symlink ld.lld: %s", ec.message().c_str()); return; }
        ld = link;
      }
      cfg.compiler = clangPath;
      cfg.compileFlags.push_back("-resource-dir=" + tcDir + "/clang-resource");  // headers builtin (stddef.h...) do MESMO clang
      cfg.linkFlags.push_back("--ld-path=" + ld);
      pipeline = std::make_unique<BuildPipeline>(cfg, make_exec_backend(workDir));
      return;
    }

    // Modo BIBLIOTECA: clang+lld em processo, via libci_clang_host.so (ver README_TOOLCHAIN.md).
    host = dlopen((tcDir + "/libci_clang_host.so").c_str(), RTLD_NOW | RTLD_LOCAL);
    if (host) clangMain = reinterpret_cast<ClangMain>(dlsym(host, "ci_clang_main"));
    if (!clangMain) { LOGE("toolchain: %s", dlerror()); return; }
    cfg.compiler = "clang++";
    pipeline = std::make_unique<BuildPipeline>(cfg, [this](const std::vector<std::string>& argv, int timeoutMs) {
      IsoOptions o;
      o.timeoutMs = timeoutMs;
      return run_isolated([&] {
        std::vector<const char*> a;
        for (const auto& x : argv) a.push_back(x.c_str());
        a.push_back(nullptr);
        return clangMain(static_cast<int>(a.size()) - 1, a.data());
      }, "", o);
    });
  }

  ~ExecEngine() {
    cancel.store(true);
    pool.stop();
    if (JNIEnv* env = current_env()) env->DeleteGlobalRef(listener);
  }

  bool ready() const { return pipeline != nullptr; }

  void run(jlong req, std::string src, std::string in, std::vector<std::string> flags, int compileMs, int runMs) {
    cancel.store(false);
    jint status = kInternal, code = 0;
    bool hit = false;
    int64_t compileUs = 0, runUs = 0;
    std::string out;

    pipeline->set_compile_timeout_ms(compileMs);
    if (!pchText.empty()) pipeline->ensure_pch(pchText);  // idempotente; 1ª vez compila, depois só confere o arquivo
    const BuildResult b = pipeline->build(src, flags);
    hit = b.cacheHit;
    compileUs = b.compileUs;
    if (!b.ok) {
      status = b.timedOut ? kTimeout : kCompileError;
      out = b.log;
    } else {
      IsoOptions o;
      o.timeoutMs = runMs;
      o.cancel = &cancel;
      const IsoResult r = run_isolated([&] { return run_so_main(b.soPath, {"program"}); }, in, o);
      runUs = r.micros;
      out = r.output;
      if (r.canceled) status = kCanceled;
      else if (r.timedOut) status = kTimeout;
      else if (r.forkFailed) status = kInternal;
      else if (r.signal) { status = kCrashed; code = r.signal; }
      else { status = kOk; code = r.exitCode; }
    }
    busy.store(false);

    if (JNIEnv* env = current_env()) {
      std::vector<char16_t> u(out.size() + 1);  // decodificador tolerante: bytes inválidos viram U+FFFD (NewStringUTF abortaria)
      const size_t n = utf8_to_utf16(reinterpret_cast<const uint8_t*>(out.data()), out.size(), u.data());
      jstring js = env->NewString(reinterpret_cast<const jchar*>(u.data()), static_cast<jsize>(n));
      env->CallVoidMethod(listener, onDone, req, status, code, static_cast<jboolean>(hit), static_cast<jlong>(compileUs),
                          static_cast<jlong>(runUs), js);
      if (env->ExceptionCheck()) env->ExceptionClear();
      env->DeleteLocalRef(js);
    }
  }

  ThreadPool pool;
  std::string pchText;
  void* host = nullptr;
  ClangMain clangMain = nullptr;
  std::unique_ptr<BuildPipeline> pipeline;
  jobject listener = nullptr;
  jmethodID onDone = nullptr;
  std::atomic<bool> cancel{false}, busy{false};
};

std::atomic<ExecEngine*> g_exec{nullptr};

jboolean nExecInit(JNIEnv* env, jclass, jstring tcDir, jstring clangPath, jstring ldPath, jstring cacheDir, jstring workDir, jstring id,
                   jstring pch, jobject listener) {
  delete g_exec.exchange(nullptr);
  auto* e = new ExecEngine(env, listener, to_utf8(env, tcDir), to_utf8(env, clangPath), to_utf8(env, ldPath), to_utf8(env, cacheDir),
                           to_utf8(env, workDir), to_utf8(env, id), to_utf8(env, pch));
  if (!e->ready()) { delete e; return JNI_FALSE; }
  g_exec.store(e);
  return JNI_TRUE;
}

jboolean nBuildAndRun(JNIEnv* env, jclass, jstring source, jstring stdinText, jstring flags, jint compileMs, jint runMs, jlong req) {
  ExecEngine* e = g_exec.load();
  if (!e || e->busy.exchange(true)) return JNI_FALSE;  // um por vez
  std::vector<std::string> fl;
  const std::string f = to_utf8(env, flags);
  for (size_t i = 0; i < f.size();) {
    const size_t j = f.find('\n', i);
    const size_t end = j == std::string::npos ? f.size() : j;
    if (end > i) fl.push_back(f.substr(i, end - i));
    i = end + 1;
  }
  std::string src = to_utf8(env, source), in = to_utf8(env, stdinText);
  struct Job {  // > 56 bytes não cabe na Task inline: vai por ponteiro
    ExecEngine* e; jlong req; std::string src, in; std::vector<std::string> fl; int cm, rm;
  };
  auto* job = new Job{e, req, std::move(src), std::move(in), std::move(fl), compileMs, runMs};
  if (!e->pool.submit(Task([job] { job->e->run(job->req, std::move(job->src), std::move(job->in), std::move(job->fl), job->cm, job->rm); delete job; }))) {
    delete job;
    e->busy.store(false);
    return JNI_FALSE;
  }
  return JNI_TRUE;
}

void nExecCancel(JNIEnv*, jclass) {
  if (ExecEngine* e = g_exec.load()) e->cancel.store(true);
}
void nExecShutdown(JNIEnv*, jclass) { delete g_exec.exchange(nullptr); }

const JNINativeMethod kMethods[] = {
    {"nInit", "(ILcom/dev/codeinjector/nativecore/NativeCore$Listener;)V", reinterpret_cast<void*>(nInit)},
    {"nShutdown", "()V", reinterpret_cast<void*>(nShutdown)},
    {"nReadFile", "(ILjava/nio/ByteBuffer;II)J", reinterpret_cast<void*>(nReadFile)},
    {"nWriteFile", "(ILjava/nio/ByteBuffer;I)J", reinterpret_cast<void*>(nWriteFile)},
    {"nAnalyzeAsync", "(Ljava/nio/ByteBuffer;ILjava/nio/ByteBuffer;JZ)Z", reinterpret_cast<void*>(nAnalyzeAsync)},
    {"nSurfaceCreated", "(Landroid/view/Surface;)V", reinterpret_cast<void*>(nSurfaceCreated)},
    {"nSurfaceChanged", "(II)V", reinterpret_cast<void*>(nSurfaceChanged)},
    {"nSurfaceDestroyed", "()V", reinterpret_cast<void*>(nSurfaceDestroyed)},
    {"nSetAtlas", "(Ljava/nio/ByteBuffer;IIIIIII)V", reinterpret_cast<void*>(nSetAtlas)},
    {"nSetScroll", "(F)V", reinterpret_cast<void*>(nSetScroll)},
    {"nSetPaused", "(Z)V", reinterpret_cast<void*>(nSetPaused)},
    {"nRequestFrame", "()V", reinterpret_cast<void*>(nRequestFrame)},
    {"nExecInit", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/dev/codeinjector/nativecore/NativeCore$ExecListener;)Z", reinterpret_cast<void*>(nExecInit)},
    {"nBuildAndRun", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIJ)Z", reinterpret_cast<void*>(nBuildAndRun)},
    {"nExecCancel", "()V", reinterpret_cast<void*>(nExecCancel)},
    {"nExecShutdown", "()V", reinterpret_cast<void*>(nExecShutdown)},
};

}  // namespace
}  // namespace ci

extern "C" CI_EXPORT jint JNI_OnLoad(JavaVM* vm, void*) {
  ci::g_vm = vm;
  JNIEnv* env = nullptr;
  if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) return JNI_ERR;
  jclass cls = env->FindClass(ci::kClassName);
  if (!cls) return JNI_ERR;
  if (env->RegisterNatives(cls, ci::kMethods, static_cast<jint>(sizeof(ci::kMethods) / sizeof(ci::kMethods[0]))) != JNI_OK) {
    LOGE("RegisterNatives falhou");
    return JNI_ERR;
  }
  return JNI_VERSION_1_6;
}
