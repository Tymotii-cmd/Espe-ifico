#include "syntax/py_lexer.hpp"

#include <algorithm>
#include <string_view>

namespace ci::syntax {
namespace {

enum class Cat : uint8_t { kKeyword, kBuiltin };
struct Entry {
  std::u16string_view w;
  Cat c;
};

const std::vector<Entry>& table() {
  static const std::vector<Entry> t = [] {
    std::vector<Entry> v;
    for (std::u16string_view k : {u"False", u"None", u"True", u"and", u"as", u"assert", u"async", u"await", u"break",
                                  u"class", u"continue", u"def", u"del", u"elif", u"else", u"except", u"finally",
                                  u"for", u"from", u"global", u"if", u"import", u"in", u"is", u"lambda", u"nonlocal",
                                  u"not", u"or", u"pass", u"raise", u"return", u"try", u"while", u"with", u"yield"})
      v.push_back({k, Cat::kKeyword});
    for (std::u16string_view b :
         {u"print", u"input", u"len", u"range", u"int", u"str", u"float", u"bool", u"list", u"dict", u"set", u"tuple",
          u"open", u"enumerate", u"zip", u"map", u"filter", u"sorted", u"reversed", u"sum", u"min", u"max", u"abs",
          u"round", u"isinstance", u"type", u"super", u"any", u"all", u"chr", u"ord", u"repr", u"format", u"hasattr",
          u"getattr", u"setattr", u"iter", u"next", u"divmod", u"pow", u"hex", u"bin", u"id", u"dir", u"vars",
          u"callable", u"bytes", u"frozenset", u"object", u"slice", u"Exception", u"ValueError", u"TypeError",
          u"KeyError", u"IndexError", u"NameError", u"AttributeError", u"ZeroDivisionError", u"FileNotFoundError",
          u"ImportError", u"RuntimeError", u"StopIteration", u"KeyboardInterrupt", u"SystemExit", u"OSError",
          u"NotImplementedError", u"AssertionError", u"Ellipsis", u"NotImplemented"})
      v.push_back({b, Cat::kBuiltin});
    std::sort(v.begin(), v.end(), [](const Entry& a, const Entry& b) { return a.w < b.w; });
    return v;
  }();
  return t;
}

inline bool is_digit(char16_t c) { return c >= u'0' && c <= u'9'; }
// Aproximação de Char.isLetter() do Kotlin: ASCII exato; acima de 0xBF conta como letra,
// exceto blocos de pontuação/espaços Unicode.
inline bool is_alpha(char16_t c) {
  if (c < 0x80) return (c >= u'a' && c <= u'z') || (c >= u'A' && c <= u'Z');
  if (c == 0xAA || c == 0xB5 || c == 0xBA) return true;
  if (c < 0xC0) return false;
  if (c >= 0x2000 && c <= 0x206F) return false;
  if (c >= 0x3000 && c <= 0x303F) return false;
  return true;
}
inline bool is_ident_start(char16_t c) { return c == u'_' || is_alpha(c); }
inline bool is_ident_part(char16_t c) { return is_ident_start(c) || is_digit(c); }
inline bool is_ws(char16_t c) { return c == u' ' || c == u'\t' || c == u'\r' || c == u'\f' || c == u'\v'; }

class Lexer {
 public:
  Lexer(const char16_t* t, size_t n, LexOutput& o) : t_(t), n_(static_cast<int32_t>(n)), o_(o) {}

  void run() {
    o_.clear();
    int32_t lc = 1;
    for (int32_t k = 0; k < n_; ++k) lc += (t_[k] == u'\n');
    lineCount_ = lc;
    o_.lines.assign(static_cast<size_t>(lc), LineInfo{-1, 0, 0, 0, 0});

    int32_t expectName = -1;
    int32_t i = 0;
    while (i < n_) {
      const char16_t c = t_[i];
      if (c == u'\n') {
        end_line(i);
        ++i;
      } else if (c == u'\\' && i + 1 < n_ && t_[i + 1] == u'\n') {
        o_.lines[line_].cont = 1;
        ++i;
      } else if (c == u'#') {
        int32_t e = i;
        while (e < n_ && t_[e] != u'\n') ++e;
        o_.lines[line_].commentPos = i;
        o_.spans.push_back({i, e, kComment});
        i = e;
      } else if (c == u'"' || c == u'\'') {
        i = scan_string(i, i);
      } else if (is_ident_start(c)) {
        int32_t j = i;
        while (j < n_ && is_ident_part(t_[j])) ++j;
        const int32_t len = j - i;
        if (j < n_ && (t_[j] == u'"' || t_[j] == u'\'') && len <= 2 && is_str_prefix(i, j)) {
          i = scan_string(i, j);
          continue;
        }
        const bool isAttr = prev_sig(i) == u'.';
        const int32_t was = expectName;
        expectName = -1;
        int32_t tok = -1;
        std::u16string_view w(t_ + i, static_cast<size_t>(len));
        if (was >= 0) {
          tok = was;
        } else if (!isAttr) {
          if (w == u"self" || w == u"cls") {
            tok = kSelf;
          } else {
            const auto& tb = table();
            auto it = std::lower_bound(tb.begin(), tb.end(), w, [](const Entry& e, std::u16string_view x) { return e.w < x; });
            if (it != tb.end() && it->w == w) tok = it->c == Cat::kKeyword ? kKeyword : kBuiltin;
          }
        }
        if (!isAttr && was < 0) {
          if (w == u"def") expectName = kFunction;
          else if (w == u"class") expectName = kClass;
        }
        if (tok >= 0) o_.spans.push_back({i, j, tok});
        i = j;
      } else if (is_digit(c) || (c == u'.' && i + 1 < n_ && is_digit(t_[i + 1]))) {
        int32_t j = i + 1;
        const bool hex = i + 1 < n_ && t_[i] == u'0' && t_[i + 1] == u'x';
        while (j < n_) {
          const char16_t d = t_[j];
          if (is_ident_part(d) || d == u'.') ++j;
          else if ((d == u'+' || d == u'-') && (t_[j - 1] == u'e' || t_[j - 1] == u'E') && !hex) ++j;
          else break;
        }
        o_.spans.push_back({i, j, kNumber});
        i = j;
      } else if (c == u'@' && only_ws_before(i)) {
        int32_t j = i + 1;
        while (j < n_ && (is_ident_part(t_[j]) || t_[j] == u'.')) ++j;
        o_.spans.push_back({i, j, kDecorator});
        i = j;
      } else if (c == u'(' || c == u'[' || c == u'{') {
        o_.stack.push_back({c, line_, i - lineStart_});
        ++i;
      } else if (c == u')' || c == u']' || c == u'}') {
        const char16_t want = c == u')' ? u'(' : c == u']' ? u'[' : u'{';
        const int32_t col = i - lineStart_;
        if (o_.stack.empty()) {
          o_.issues.push_back({kUnmatchedClose, line_ + 1, col + 1, line_ + 1, col + 2, c, 0, 0});
        } else {
          const Bracket top = o_.stack.back();
          o_.stack.pop_back();
          if (top.ch != want)
            o_.issues.push_back({kMismatchedClose, line_ + 1, col + 1, line_ + 1, col + 2, c, top.ch,
                                 top.line != line_ ? top.line + 1 : 0});
        }
        ++i;
      } else {
        ++i;
      }
    }
    o_.lines[std::min(line_, lineCount_ - 1)].depthEnd = static_cast<int32_t>(o_.stack.size());
    for (const Bracket& b : o_.stack)
      o_.issues.push_back({kNeverClosed, b.line + 1, b.col + 1, b.line + 1, b.col + 2, b.ch, 0, 0});
  }

 private:
  void end_line(int32_t p) {
    o_.lines[line_].depthEnd = static_cast<int32_t>(o_.stack.size());
    ++line_;
    lineStart_ = p + 1;
    if (line_ < lineCount_) o_.lines[line_].depthStart = static_cast<int32_t>(o_.stack.size());
  }

  bool is_str_prefix(int32_t b, int32_t e) const {
    for (int32_t k = b; k < e; ++k) {
      const char16_t c = static_cast<char16_t>(t_[k] | 0x20);  // minúscula (só vale p/ letras ASCII)
      if (c != u'r' && c != u'b' && c != u'u' && c != u'f') return false;
      if (t_[k] >= 0x80) return false;
    }
    return true;
  }

  char16_t prev_sig(int32_t p) const {
    int32_t k = p - 1;
    while (k >= lineStart_ && (t_[k] == u' ' || t_[k] == u'\t')) --k;
    return k >= lineStart_ ? t_[k] : u'\0';
  }

  bool only_ws_before(int32_t p) const {
    for (int32_t k = lineStart_; k < p; ++k)
      if (!is_ws(t_[k])) return false;
    return true;
  }

  void in_string_line() {
    if (line_ < lineCount_) o_.lines[line_].inString = 1;
  }

  int32_t scan_string(int32_t startPos, int32_t q) {
    const char16_t quote = t_[q];
    const bool triple = q + 2 < n_ && t_[q + 1] == quote && t_[q + 2] == quote;
    const int32_t startLine = line_, startCol = startPos - lineStart_;
    int32_t j = q + (triple ? 3 : 1);
    while (j < n_) {
      const char16_t ch = t_[j];
      if (ch == u'\\') {
        if (j + 1 < n_ && t_[j + 1] == u'\n') {
          end_line(j + 1);
          in_string_line();
        }
        j += 2;
        continue;
      }
      if (ch == u'\n') {
        if (!triple) {
          o_.issues.push_back({kUnterminatedString, startLine + 1, startCol + 1, startLine + 1, startCol + 2, 0, 0, startLine + 1});
          o_.spans.push_back({startPos, j, kString});
          return j;
        }
        end_line(j);
        in_string_line();
        ++j;
        continue;
      }
      if (triple) {
        if (ch == quote && j + 2 < n_ && t_[j + 1] == quote && t_[j + 2] == quote) {
          j += 3;
          o_.spans.push_back({startPos, j, kString});
          return j;
        }
      } else if (ch == quote) {
        ++j;
        o_.spans.push_back({startPos, j, kString});
        return j;
      }
      ++j;
    }
    if (triple)
      o_.issues.push_back({kUnterminatedTriple, startLine + 1, startCol + 1, startLine + 1, startCol + 4, 0, 0, lineCount_});
    else
      o_.issues.push_back({kUnterminatedString, startLine + 1, startCol + 1, startLine + 1, startCol + 2, 0, 0, startLine + 1});
    o_.spans.push_back({startPos, n_, kString});
    return n_;
  }

  const char16_t* t_;
  int32_t n_;
  LexOutput& o_;
  int32_t line_ = 0, lineStart_ = 0, lineCount_ = 1;
};

}  // namespace

void lex_python(const char16_t* text, size_t n, LexOutput& out) { Lexer(text, n, out).run(); }

}  // namespace ci::syntax
