#pragma once
// Lexer de Python (port do lex() do SyntaxAnalyzer.kt) operando direto em UTF-16,
// então os offsets são os mesmos de String/TextFieldValue no Kotlin.
#include <cstddef>
#include <cstdint>
#include <vector>

namespace ci::syntax {

// Mesma ordem do enum Tok do Kotlin.
enum Tok : int32_t { kKeyword, kBuiltin, kString, kComment, kNumber, kDecorator, kFunction, kClass, kSelf };

struct Span {  // 12 bytes: vai para o buffer direto com um único memcpy
  int32_t start, end, tok;
};

enum IssueCode : int32_t {
  kUnterminatedString = 1,  // aux = linha (1-based) onde foi detectado
  kUnterminatedTriple = 2,  // aux = total de linhas
  kUnmatchedClose = 3,      // ch1 = caractere de fechamento
  kMismatchedClose = 4,     // ch1 = fechamento, ch2 = abertura, aux = linha da abertura (0 se a mesma)
  kNeverClosed = 5,         // ch1 = abertura
};

struct Issue {  // 32 bytes. line/col 1-based
  int32_t code, line, col, endLine, endCol, ch1, ch2, aux;
};

struct LineInfo {
  int32_t commentPos;  // offset absoluto do '#', ou -1
  int32_t depthStart, depthEnd;  // profundidade de colchetes no início/fim da linha
  uint8_t inString;    // linha começa dentro de string multilinha
  uint8_t cont;        // termina com '\' de continuação
};

struct Bracket {
  int32_t ch, line, col;
};

struct LexOutput {
  std::vector<Span> spans;
  std::vector<Issue> issues;
  std::vector<LineInfo> lines;
  std::vector<Bracket> stack;  // scratch reutilizado
  void clear() {
    spans.clear();
    issues.clear();
    lines.clear();
    stack.clear();
  }
};

static_assert(sizeof(Span) == 12 && sizeof(Issue) == 32, "layout usado pelo ponte JNI");

// `out` é limpo e preenchido; os vetores mantêm capacidade (sem realocar em regime).
void lex_python(const char16_t* text, size_t n, LexOutput& out);

}  // namespace ci::syntax
