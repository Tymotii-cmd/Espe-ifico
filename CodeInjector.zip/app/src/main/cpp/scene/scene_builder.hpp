#pragma once
// Monta, na CPU, os vértices dos quads visíveis (texto monoespaçado + realce).
// Sem OpenGL aqui: tudo testável no PC e reaproveitável por qualquer backend.
#include <cstddef>
#include <cstdint>

#include "scene/snapshot.hpp"

namespace ci {

struct Vertex {
  float x, y, u, v;
  uint32_t rgba;  // bytes R,G,B,A (little-endian: A<<24 | B<<16 | G<<8 | R)
};
static_assert(sizeof(Vertex) == 20, "layout do VBO");

// Atlas A8 em grade: células [first, first+count) = glifos ASCII; célula `count` = bloco branco.
struct AtlasInfo {
  int w = 0, h = 0;
  int cols = 0, rows = 0;
  int cellW = 0, cellH = 0;
  int first = 32, count = 95;
};

struct Theme {
  uint32_t bg, fg;
  uint32_t tok[9];  // ordem de syntax::Tok; formato ARGB (Color.toArgb())
};

struct View {
  float width, height;
  float scrollY;
  float padLeft;
  int tabWidth;
};

inline uint32_t argb_to_rgba(uint32_t c) {
  return (c & 0xFF00FF00u) | ((c & 0x00FF0000u) >> 16) | ((c & 0x000000FFu) << 16);
}

Theme default_theme();

// Retorna nº de quads escritos em `out` (4 vértices cada). Máx `maxQuads`.
size_t build_scene(const Snapshot& s, const AtlasInfo& a, const Theme& th, const View& v, Vertex* out, size_t maxQuads);

}  // namespace ci
