#pragma once
// Snapshot imutável do texto + resultado da análise. Vive num pool pré-alocado:
// os vetores mantêm a capacidade entre usos, então em regime não há malloc por análise.
#include <memory>
#include <vector>

#include "core/line_index.hpp"
#include "core/mpmc_queue.hpp"
#include "syntax/py_lexer.hpp"

namespace ci {

struct Snapshot {
  std::vector<char16_t> text;
  LineIndex lines;
  syntax::LexOutput lex;
  uint64_t req = 0;
  int32_t* out = nullptr;   // buffer direto do Kotlin (resultado serializado)
  size_t outCapInts = 0;
  void* outRef = nullptr;   // jobject (global ref) que mantém `out` vivo
  bool publish = false;     // enviar ao renderer?
};

class SnapshotPool {
 public:
  explicit SnapshotPool(size_t n, size_t initialChars = 1u << 16) : slots_(n), free_(n) {
    for (auto& s : slots_) {
      s = std::make_unique<Snapshot>();
      s->text.reserve(initialChars);
      Snapshot* p = s.get();
      free_.try_push(std::move(p));
    }
  }
  Snapshot* acquire() {
    Snapshot* s = nullptr;
    return free_.try_pop(s) ? s : nullptr;
  }
  void release(Snapshot* s) {
    s->out = nullptr;
    s->outRef = nullptr;
    s->publish = false;
    free_.try_push(std::move(s));
  }

 private:
  std::vector<std::unique_ptr<Snapshot>> slots_;
  MpmcQueue<Snapshot*> free_;
};

}  // namespace ci
