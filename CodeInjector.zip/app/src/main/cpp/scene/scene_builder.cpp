#include "scene/scene_builder.hpp"

#include <algorithm>
#include <cmath>

namespace ci {

Theme default_theme() {
  Theme t{};
  t.bg = 0xFF1E1F22;
  t.fg = 0xFFBCBEC4;
  t.tok[syntax::kKeyword] = 0xFFCF8E6D;
  t.tok[syntax::kBuiltin] = 0xFF8888C6;
  t.tok[syntax::kString] = 0xFF6AAB73;
  t.tok[syntax::kComment] = 0xFF7A7E85;
  t.tok[syntax::kNumber] = 0xFF2AACB8;
  t.tok[syntax::kDecorator] = 0xFFB3AE60;
  t.tok[syntax::kFunction] = 0xFF56A8F5;
  t.tok[syntax::kClass] = 0xFFE0B14C;
  t.tok[syntax::kSelf] = 0xFF94558D;
  return t;
}

size_t build_scene(const Snapshot& s, const AtlasInfo& a, const Theme& th, const View& v, Vertex* out, size_t maxQuads) {
  if (a.cols <= 0 || a.cellW <= 0 || a.cellH <= 0 || a.w <= 0 || a.h <= 0 || s.lines.count() == 0) return 0;

  const char16_t* text = s.text.data();
  const auto& spans = s.lex.spans;
  const float cw = static_cast<float>(a.cellW), ch = static_cast<float>(a.cellH);
  const float invW = 1.0f / static_cast<float>(a.w), invH = 1.0f / static_cast<float>(a.h);
  const int maxCol = static_cast<int>(std::ceil((v.width - v.padLeft) / cw)) + 1;
  const long firstLine = std::max(0l, static_cast<long>(std::floor(v.scrollY / ch)));
  const long lastLine = std::min(static_cast<long>(s.lines.count()) - 1, static_cast<long>(std::floor((v.scrollY + v.height) / ch)));
  const int tab = v.tabWidth > 0 ? v.tabWidth : 4;
  const uint32_t fg = argb_to_rgba(th.fg);

  size_t quads = 0;
  for (long li = firstLine; li <= lastLine && quads < maxQuads; ++li) {
    const int32_t ls = static_cast<int32_t>(s.lines.start(static_cast<size_t>(li)));
    const int32_t le = static_cast<int32_t>(s.lines.end(static_cast<size_t>(li)));
    // primeiro span que termina depois do início da linha (spans são ordenados e disjuntos)
    size_t si = static_cast<size_t>(
        std::partition_point(spans.begin(), spans.end(), [&](const syntax::Span& sp) { return sp.end <= ls; }) - spans.begin());
    const float y0 = std::round(static_cast<float>(li) * ch - v.scrollY);
    int col = 0;
    for (int32_t p = ls; p < le && col <= maxCol && quads < maxQuads; ++p) {
      const char16_t c = text[p];
      if (c == u'\t') {
        col += tab - (col % tab);
        continue;
      }
      if (c == u'\r') continue;
      const int cur = col++;
      if (c == u' ') continue;
      while (si < spans.size() && spans[si].end <= p) ++si;
      uint32_t color = fg;
      if (si < spans.size() && spans[si].start <= p) color = argb_to_rgba(th.tok[spans[si].tok]);

      const int idx = (c >= a.first && c < a.first + a.count) ? c - a.first : '?' - a.first;
      const float u0 = static_cast<float>((idx % a.cols) * a.cellW) * invW;
      const float v0 = static_cast<float>((idx / a.cols) * a.cellH) * invH;
      const float u1 = u0 + cw * invW, v1 = v0 + ch * invH;
      const float x0 = std::round(v.padLeft + static_cast<float>(cur) * cw), x1 = x0 + cw, y1 = y0 + ch;
      Vertex* q = out + quads * 4;
      q[0] = {x0, y0, u0, v0, color};
      q[1] = {x1, y0, u1, v0, color};
      q[2] = {x0, y1, u0, v1, color};
      q[3] = {x1, y1, u1, v1, color};
      ++quads;
    }
  }
  return quads;
}

}  // namespace ci
