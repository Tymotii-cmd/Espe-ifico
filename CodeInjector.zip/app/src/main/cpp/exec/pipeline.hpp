#pragma once
// Orquestra: fonte -> (cache?) -> compilador -> .so. O compilador é injetado (CompileBackend):
//  * Android: clang+lld do pacote baixado, carregados como biblioteca (ver README_TOOLCHAIN.md);
//  * host/testes: g++ via execvp.
#include <cstdint>
#include <functional>
#include <string>
#include <string_view>
#include <vector>

#include "exec/build_cache.hpp"
#include "exec/isolated.hpp"

namespace ci {

struct BuildConfig {
  std::string cacheDir, workDir;
  std::string toolchainId;                 // entra na chave do cache: trocar de toolchain invalida tudo
  std::string compiler = "clang++";        // argv[0]
  std::vector<std::string> compileFlags;   // ex.: -std=c++20 -O1 -fPIC ... (iguais p/ PCH e programa)
  std::vector<std::string> linkFlags;      // ex.: -shared -static-libstdc++ ...
  int compileTimeoutMs = 60000;
  uint64_t cacheMaxBytes = 256ull << 20;
  std::string pchExt = ".pch";             // ".gch" com GCC
};

struct BuildResult {
  bool ok = false, cacheHit = false, timedOut = false;
  std::string soPath;
  std::string log;                          // saída do compilador
  int64_t hashUs = 0, compileUs = 0;        // tempos por fase
};

using CompileBackend = std::function<IsoResult(const std::vector<std::string>& argv, int timeoutMs)>;

class BuildPipeline {
 public:
  BuildPipeline(BuildConfig cfg, CompileBackend backend);
  BuildResult build(std::string_view source, const std::vector<std::string>& extraFlags = {});
  // Pré-compila `headerText` (ex.: #include <iostream>/<vector>/...). Usado automaticamente quando
  // build() recebe extraFlags vazio (flags diferentes invalidariam o PCH). Idempotente.
  bool ensure_pch(std::string_view headerText);
  void set_compile_timeout_ms(int ms) { cfg_.compileTimeoutMs = ms; }  // vale para as próximas compilações

 private:
  std::string key_for(std::string_view source, const std::vector<std::string>& extra) const;
  BuildConfig cfg_;
  CompileBackend backend_;
  BuildCache cache_;
  std::string pchHeader_;  // caminho de pch.hpp (o .pch/.gch fica ao lado)
};

}  // namespace ci
