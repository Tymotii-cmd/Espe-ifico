#include "exec/build_cache.hpp"

#include <sys/stat.h>

#include <algorithm>
#include <filesystem>
#include <vector>

namespace fs = std::filesystem;

namespace ci {

BuildCache::BuildCache(std::string dir, uint64_t maxBytes) : dir_(std::move(dir)), max_(maxBytes) {
  std::error_code ec;
  fs::create_directories(dir_, ec);
}

bool BuildCache::lookup(const std::string& key, std::string& path) const {
  const std::string p = path_for(key);
  std::error_code ec;
  if (!fs::is_regular_file(p, ec)) return false;
  fs::last_write_time(p, fs::file_time_type::clock::now(), ec);
  path = p;
  return true;
}

bool BuildCache::commit(const std::string& tmpPath, const std::string& key) {
  ::chmod(tmpPath.c_str(), 0555);  // somente leitura: exigência do Android 14 para código carregado dinamicamente
  std::error_code ec;
  fs::rename(tmpPath, path_for(key), ec);
  if (ec) return false;
  evict();
  return true;
}

void BuildCache::evict() {
  struct E { fs::file_time_type t; uint64_t size; fs::path p; };
  std::vector<E> v;
  uint64_t total = 0;
  std::error_code ec;
  for (fs::directory_iterator it(dir_, ec), end; !ec && it != end; it.increment(ec)) {
    if (it->path().extension() != ".so") continue;
    std::error_code e2;
    const auto sz = it->file_size(e2);
    const auto tm = it->last_write_time(e2);
    if (e2) continue;
    v.push_back({tm, sz, it->path()});
    total += sz;
  }
  std::sort(v.begin(), v.end(), [](const E& a, const E& b) { return a.t < b.t; });
  for (size_t i = 0; i + 1 < v.size() && total > max_; ++i) {  // o mais novo nunca é removido
    std::error_code e3;
    fs::remove(v[i].p, e3);
    total -= v[i].size;
  }
}

}  // namespace ci
