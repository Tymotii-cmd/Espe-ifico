#pragma once
// Cache de .so por hash do conteúdo (fonte + flags + versão do toolchain). Código inalterado nunca recompila.
// Despejo LRU por mtime. Escritas atômicas (rename) => nunca expõe .so pela metade.
#include <cstdint>
#include <string>

namespace ci {

class BuildCache {
 public:
  BuildCache(std::string dir, uint64_t maxBytes);
  std::string path_for(const std::string& key) const { return dir_ + "/" + key + ".so"; }
  bool lookup(const std::string& key, std::string& path) const;           // hit => atualiza mtime (LRU)
  bool commit(const std::string& tmpPath, const std::string& key);        // move p/ o cache, 0555, despeja excesso
  void evict();

 private:
  std::string dir_;
  uint64_t max_;
};

}  // namespace ci
