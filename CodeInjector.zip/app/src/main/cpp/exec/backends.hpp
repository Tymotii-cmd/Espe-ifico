#pragma once
#include <string>

#include "exec/pipeline.hpp"

namespace ci {

// Backend que executa argv[0] (execvp) num filho isolado, com TMPDIR apontando para `tmpDir`
// (o Android não tem /tmp; o clang precisa de um diretório temporário gravável).
// Serve para clang/lld como executáveis e, nos testes, para g++.
CompileBackend make_exec_backend(std::string tmpDir);

}  // namespace ci
