#include "exec/pipeline.hpp"

#include <unistd.h>

#include <chrono>
#include <cstdio>
#include <filesystem>
#include <fstream>

#include "core/sha256.hpp"

namespace fs = std::filesystem;

namespace ci {
namespace {
using Clock = std::chrono::steady_clock;
int64_t us_since(Clock::time_point t) { return std::chrono::duration_cast<std::chrono::microseconds>(Clock::now() - t).count(); }

bool write_file(const std::string& path, std::string_view data) {
  const std::string tmp = path + ".w" + std::to_string(getpid());
  {
    std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
    if (!f) return false;
    f.write(data.data(), static_cast<std::streamsize>(data.size()));
    if (!f) return false;
  }
  std::error_code ec;
  fs::rename(tmp, path, ec);
  return !ec;
}
}  // namespace

BuildPipeline::BuildPipeline(BuildConfig cfg, CompileBackend backend)
    : cfg_(std::move(cfg)), backend_(std::move(backend)), cache_(cfg_.cacheDir, cfg_.cacheMaxBytes) {
  std::error_code ec;
  fs::create_directories(cfg_.workDir, ec);
}

std::string BuildPipeline::key_for(std::string_view source, const std::vector<std::string>& extra) const {
  Sha256 h;
  auto add = [&](std::string_view s) { h.update(s.data(), s.size()); const char z = 0; h.update(&z, 1); };
  add(cfg_.toolchainId);
  add(cfg_.compiler);
  for (auto& f : cfg_.compileFlags) add(f);
  add("|");
  for (auto& f : cfg_.linkFlags) add(f);
  add("|");
  for (auto& f : extra) add(f);
  add("|");
  add(pchHeader_);
  add(source);
  return to_hex(h.finish());
}

bool BuildPipeline::ensure_pch(std::string_view headerText) {
  const std::string id = sha256_hex(cfg_.toolchainId + '\0' + std::string(headerText)).substr(0, 16);
  const std::string dir = cfg_.workDir + "/pch-" + id;
  std::error_code ec;
  fs::create_directories(dir, ec);
  const std::string hdr = dir + "/pch.hpp", out = hdr + cfg_.pchExt;
  if (fs::exists(out, ec)) { pchHeader_ = hdr; return true; }
  if (!write_file(hdr, headerText)) return false;
  std::vector<std::string> argv{cfg_.compiler, "-x", "c++-header"};
  argv.insert(argv.end(), cfg_.compileFlags.begin(), cfg_.compileFlags.end());
  const std::string tmp = out + ".tmp";
  argv.push_back(hdr);
  argv.push_back("-o");
  argv.push_back(tmp);
  const IsoResult r = backend_(argv, cfg_.compileTimeoutMs);
  if (r.signal || r.exitCode != 0) { fs::remove(tmp, ec); return false; }
  fs::rename(tmp, out, ec);
  if (ec) return false;
  pchHeader_ = hdr;
  return true;
}

BuildResult BuildPipeline::build(std::string_view source, const std::vector<std::string>& extra) {
  BuildResult res;
  auto t = Clock::now();
  const bool usePch = extra.empty() && !pchHeader_.empty();
  const std::string savedPch = pchHeader_;
  if (!usePch) pchHeader_.clear();  // PCH só vale com as flags-base
  const std::string key = key_for(source, extra);
  pchHeader_ = savedPch;
  res.hashUs = us_since(t);

  if (cache_.lookup(key, res.soPath)) {
    res.ok = res.cacheHit = true;
    return res;
  }

  t = Clock::now();
  const std::string src = cfg_.workDir + "/" + key + ".cpp";
  const std::string tmpOut = cfg_.cacheDir + "/" + key + ".so.tmp" + std::to_string(getpid());
  if (!write_file(src, source)) { res.log = "não consegui gravar o fonte em " + cfg_.workDir; return res; }

  std::vector<std::string> argv{cfg_.compiler};
  argv.insert(argv.end(), cfg_.compileFlags.begin(), cfg_.compileFlags.end());
  argv.insert(argv.end(), cfg_.linkFlags.begin(), cfg_.linkFlags.end());
  argv.insert(argv.end(), extra.begin(), extra.end());
  if (usePch) { argv.push_back("-include"); argv.push_back(pchHeader_); }
  argv.push_back(src);
  argv.push_back("-o");
  argv.push_back(tmpOut);

  const IsoResult r = backend_(argv, cfg_.compileTimeoutMs);
  res.compileUs = us_since(t);
  res.log = r.output;
  res.timedOut = r.timedOut;
  std::error_code ec;
  if (r.timedOut || r.signal || r.exitCode != 0) {
    if (r.signal) res.log += "\n[compilador terminou por sinal " + std::to_string(r.signal) + "]";
    if (r.timedOut) res.log += "\n[timeout na compilação]";
    fs::remove(tmpOut, ec);
    fs::remove(src, ec);
    return res;
  }
  fs::remove(src, ec);
  if (!cache_.commit(tmpOut, key)) { res.log += "\n[falha ao gravar no cache]"; return res; }
  res.soPath = cache_.path_for(key);
  res.ok = true;
  return res;
}

}  // namespace ci
