#include "exec/isolated.hpp"

#include <dlfcn.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <sys/wait.h>
#include <unistd.h>

#include <cerrno>
#include <chrono>
#include <cstdio>
#include <mutex>
#include <thread>

namespace ci {
namespace {
using Clock = std::chrono::steady_clock;

void set_nonblock(int fd) { fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) | O_NONBLOCK); }
void close_fd(int& fd) { if (fd >= 0) { ::close(fd); fd = -1; } }
}  // namespace

IsoResult run_isolated(const std::function<int()>& fn, std::string_view in, const IsoOptions& opt) {
  static std::once_flag once;
  std::call_once(once, [] { signal(SIGPIPE, SIG_IGN); });  // escrita no stdin de filho morto: EPIPE, não sinal

  IsoResult r;
  const auto t0 = Clock::now();
  auto finish = [&](IsoResult& x) { x.micros = std::chrono::duration_cast<std::chrono::microseconds>(Clock::now() - t0).count(); };

  int inP[2], outP[2];
  if (pipe(inP) != 0) { r.forkFailed = true; finish(r); return r; }
  if (pipe(outP) != 0) { close(inP[0]); close(inP[1]); r.forkFailed = true; finish(r); return r; }

  fflush(nullptr);  // não duplicar buffers pendentes do pai no filho
  const pid_t pid = fork();
  if (pid < 0) {
    for (int fd : {inP[0], inP[1], outP[0], outP[1]}) close(fd);
    r.forkFailed = true; finish(r); return r;
  }
  if (pid == 0) {  // ---- filho
    setpgid(0, 0);
    dup2(inP[0], 0); dup2(outP[1], 1); dup2(outP[1], 2);
    for (int fd : {inP[0], inP[1], outP[0], outP[1]}) if (fd > 2) close(fd);
    const int code = fn();
    fflush(nullptr);
    _exit(code);
  }
  // ---- pai
  setpgid(pid, pid);
  int inW = inP[1], outR = outP[0];
  close(inP[0]); close(outP[1]);
  set_nonblock(inW); set_nonblock(outR);
  size_t inOff = 0;
  if (in.empty()) close_fd(inW);

  const auto deadline = t0 + std::chrono::milliseconds(opt.timeoutMs);
  auto kill_group = [&] { kill(-pid, SIGKILL); };
  bool eof = false, killed = false;
  char buf[16384];

  while (!eof) {
    if (!killed) {
      if (opt.cancel && opt.cancel->load(std::memory_order_relaxed)) { r.canceled = true; kill_group(); killed = true; }
      else if (Clock::now() >= deadline) { r.timedOut = true; kill_group(); killed = true; }
    }
    pollfd fds[2] = {{outR, POLLIN, 0}, {inW, static_cast<short>(inW >= 0 ? POLLOUT : 0), 0}};
    const int pr = poll(fds, 2, 40);  // acorda a cada 40 ms p/ checar timeout/cancel
    if (pr < 0 && errno != EINTR) break;
    if (fds[0].revents & (POLLIN | POLLHUP | POLLERR)) {
      const ssize_t n = read(outR, buf, sizeof buf);
      if (n > 0) {
        const size_t room = opt.maxOutput > r.output.size() ? opt.maxOutput - r.output.size() : 0;
        const size_t take = static_cast<size_t>(n) < room ? static_cast<size_t>(n) : room;
        r.output.append(buf, take);
        if (take < static_cast<size_t>(n)) r.truncated = true;
      } else if (n == 0) {
        eof = true;
      } else if (errno != EAGAIN && errno != EINTR) {
        eof = true;
      }
    }
    if (inW >= 0 && (fds[1].revents & (POLLOUT | POLLERR | POLLHUP))) {
      const ssize_t w = write(inW, in.data() + inOff, in.size() - inOff);
      if (w > 0) inOff += static_cast<size_t>(w);
      if (w < 0 && errno != EAGAIN && errno != EINTR) inOff = in.size();  // filho fechou o stdin
      if (inOff >= in.size()) close_fd(inW);
    }
  }
  close_fd(inW);
  close_fd(outR);

  // Filho pode ter fechado stdout e continuar rodando: espera com o mesmo prazo.
  int status = 0;
  for (;;) {
    const pid_t w = waitpid(pid, &status, WNOHANG);
    if (w == pid) break;
    if (w < 0 && errno != EINTR) { status = 0; break; }
    if (!killed && (Clock::now() >= deadline || (opt.cancel && opt.cancel->load()))) {
      r.timedOut = !(opt.cancel && opt.cancel->load());
      r.canceled = !r.timedOut;
      kill_group(); killed = true;
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(2));
  }
  kill_group();  // netos órfãos do filho
  if (WIFSIGNALED(status)) r.signal = WTERMSIG(status);
  else if (WIFEXITED(status)) r.exitCode = WEXITSTATUS(status);
  finish(r);
  return r;
}

int run_so_main(const std::string& soPath, const std::vector<std::string>& args) {
  void* h = dlopen(soPath.c_str(), RTLD_NOW | RTLD_LOCAL);
  if (!h) { std::fprintf(stderr, "dlopen: %s\n", dlerror()); return 127; }
  using MainFn = int (*)(int, char**);
  auto m = reinterpret_cast<MainFn>(dlsym(h, "main"));
  if (!m) { std::fprintf(stderr, "o programa não tem main()\n"); return 126; }
  std::vector<std::string> store = args;
  if (store.empty()) store.push_back("program");
  std::vector<char*> argv;
  for (auto& s : store) argv.push_back(s.data());
  argv.push_back(nullptr);
  const int rc = m(static_cast<int>(store.size()), argv.data());
  std::fflush(nullptr);
  return rc;
}

}  // namespace ci
