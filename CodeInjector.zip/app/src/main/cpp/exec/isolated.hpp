#pragma once
// Execução isolada em processo filho (fork): crash, loop infinito ou exit() do código do usuário
// (ou do clang) não derrubam o app. stdin/stdout/stderr passam por pipes; timeout mata o grupo inteiro.
#include <atomic>
#include <cstdint>
#include <functional>
#include <string>
#include <string_view>
#include <vector>

namespace ci {

struct IsoOptions {
  int timeoutMs = 10000;
  size_t maxOutput = 1u << 20;               // excedente é descartado (o filho nunca bloqueia no pipe)
  std::atomic<bool>* cancel = nullptr;       // true => mata o filho
};

struct IsoResult {
  int exitCode = -1;       // válido se signal == 0
  int signal = 0;          // sinal que matou o filho (SIGSEGV...), 0 se saiu normalmente
  bool timedOut = false, canceled = false, truncated = false, forkFailed = false;
  std::string output;      // stdout+stderr intercalados, bytes crus
  int64_t micros = 0;
};

// `fn` roda no filho; seu retorno vira o exit code. O filho faz fflush(NULL) e _exit().
IsoResult run_isolated(const std::function<int()>& fn, std::string_view stdinData, const IsoOptions& opt);

// Carrega `soPath` com dlopen e chama `main(argc, argv)`. Para usar como `fn` de run_isolated.
// 127 = dlopen falhou, 126 = sem símbolo main (mensagem em stderr).
int run_so_main(const std::string& soPath, const std::vector<std::string>& args);

}  // namespace ci
