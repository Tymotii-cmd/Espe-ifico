#include "exec/backends.hpp"

#include <unistd.h>

#include <cstdlib>

namespace ci {

CompileBackend make_exec_backend(std::string tmpDir) {
  return [tmpDir = std::move(tmpDir)](const std::vector<std::string>& argv, int timeoutMs) {
    IsoOptions o;
    o.timeoutMs = timeoutMs;
    return run_isolated([&] {
      if (!tmpDir.empty()) setenv("TMPDIR", tmpDir.c_str(), 1);
      std::vector<char*> a;
      for (const auto& s : argv) a.push_back(const_cast<char*>(s.c_str()));
      a.push_back(nullptr);
      execvp(a[0], a.data());
      return 127;  // exec falhou (ex.: binário ausente / sem permissão de execução)
    }, "", o);
  };
}

}  // namespace ci
