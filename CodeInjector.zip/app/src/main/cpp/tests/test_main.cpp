// Testes de host (sem gtest, sem rede). Roda no CI com e sem sanitizers.
#include <fcntl.h>
#include <unistd.h>

#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <random>
#include <string>
#include <thread>
#include <vector>

#include "core/file_io.hpp"
#include "core/gap_buffer.hpp"
#include "core/mpmc_queue.hpp"
#include "core/sha256.hpp"
#include "exec/isolated.hpp"
#include "exec/pipeline.hpp"
#include "exec/backends.hpp"
#include <csignal>
#include <filesystem>
#include <chrono>
#include "core/thread_pool.hpp"
#include "core/utf.hpp"
#include "scene/scene_builder.hpp"
#include "syntax/py_lexer.hpp"

static int g_fail = 0, g_checks = 0;
#define CHECK(c)                                                         \
  do {                                                                   \
    ++g_checks;                                                          \
    if (!(c)) {                                                          \
      ++g_fail;                                                          \
      std::fprintf(stderr, "FAIL %s:%d  %s\n", __FILE__, __LINE__, #c); \
    }                                                                    \
  } while (0)

using std::u16string;
using namespace ci;
using namespace ci::syntax;

static u16string U(const char* s) {  // ASCII -> u16
  u16string r;
  while (*s) r.push_back(static_cast<char16_t>(*s++));
  return r;
}

static void test_utf() {
  const char* utf8 = "ol\xC3\xA1 \xE2\x82\xAC \xF0\x9F\x98\x80 fim";
  std::vector<char16_t> d(64);
  size_t n = utf8_to_utf16(reinterpret_cast<const uint8_t*>(utf8), std::strlen(utf8), d.data());
  u16string want = u"ol\u00e1 \u20ac \U0001F600 fim";
  CHECK(u16string(d.data(), n) == want);
  std::vector<uint8_t> back(want.size() * 3);
  size_t m = utf16_to_utf8(want.data(), want.size(), back.data());
  CHECK(m == std::strlen(utf8) && std::memcmp(back.data(), utf8, m) == 0);
  // inválidos
  const uint8_t bad[] = {'a', 0xFF, 'b', 0xC3, 0x28, 0xE2, 0x82};
  n = utf8_to_utf16(bad, sizeof bad, d.data());
  CHECK(d[0] == 'a' && d[1] == 0xFFFD && d[2] == 'b' && d[3] == 0xFFFD && d[4] == '(' && d[5] == 0xFFFD && d[6] == 0xFFFD && n == 7);
  // surrogate solto
  const char16_t lone[] = {u'x', 0xD800, u'y'};
  m = utf16_to_utf8(lone, 3, back.data());
  CHECK(m == 5 && back[1] == 0xEF && back[2] == 0xBF && back[3] == 0xBD);
  // ASCII longo (caminho rápido de 8 bytes)
  std::string a(1000, 'z');
  std::vector<char16_t> big(1000);
  CHECK(utf8_to_utf16(reinterpret_cast<const uint8_t*>(a.data()), 1000, big.data()) == 1000 && big[999] == 'z');
}

static std::string tmp_path() {
  char p[] = "/tmp/ci_test_XXXXXX";
  int fd = mkstemp(p);
  close(fd);
  return p;
}
static void write_bytes(const std::string& path, const std::string& b) {
  FILE* f = std::fopen(path.c_str(), "wb");
  std::fwrite(b.data(), 1, b.size(), f);
  std::fclose(f);
}

static void test_file_io() {
  // mistura de ASCII e multibyte, tamanho grande para exercitar a decodificação in-place
  std::string content;
  std::mt19937 rng(7);
  const char* pieces[] = {"abc ", "\xC3\xA9", "\xE2\x82\xAC", "\xF0\x9F\x98\x80", "\n", "def foo():\n"};
  for (int i = 0; i < 20000; ++i) content += pieces[rng() % 6];
  std::string path = tmp_path();
  write_bytes(path, content);

  // referência: decodificação fora do lugar
  std::vector<char16_t> ref(content.size());
  size_t refN = utf8_to_utf16(reinterpret_cast<const uint8_t*>(content.data()), content.size(), ref.data());

  for (size_t extra : {size_t(0), size_t(5), size_t(1000)}) {
    std::vector<char16_t> dst(content.size() + extra);
    int fd = open(path.c_str(), O_RDONLY);
    int64_t r = read_fd_utf16(fd, dst.data(), dst.size(), 1 << 26);
    close(fd);
    CHECK(r == static_cast<int64_t>(refN));
    CHECK(r > 0 && std::memcmp(dst.data(), ref.data(), refN * 2) == 0);
  }
  { // capacidade pequena
    std::vector<char16_t> dst(10);
    int fd = open(path.c_str(), O_RDONLY);
    CHECK(read_fd_utf16(fd, dst.data(), dst.size(), 1 << 26) == kErrCapacity);
    close(fd);
  }
  { // limite
    std::vector<char16_t> dst(content.size());
    int fd = open(path.c_str(), O_RDONLY);
    CHECK(read_fd_utf16(fd, dst.data(), dst.size(), 100) == kErrTooLarge);
    close(fd);
  }
  { // BOM + binário
    write_bytes(path, std::string("\xEF\xBB\xBF" "hi"));
    char16_t d[8];
    int fd = open(path.c_str(), O_RDONLY);
    CHECK(read_fd_utf16(fd, d, 8, 1000) == 2 && d[0] == 'h' && d[1] == 'i');
    close(fd);
    write_bytes(path, std::string("ab\0cd", 5));
    fd = open(path.c_str(), O_RDONLY);
    CHECK(read_fd_utf16(fd, d, 8, 1000) == kErrBinary);
    close(fd);
  }
  { // pipe (caminho streaming)
    int p[2];
    CHECK(pipe(p) == 0);
    const char msg[] = "from pipe \xC3\xA9";
    CHECK(write(p[1], msg, sizeof msg - 1) > 0);
    close(p[1]);
    char16_t d[32];
    CHECK(read_fd_utf16(p[0], d, 32, 1000) == 11 && d[10] == 0xE9);
    close(p[0]);
  }
  { // escrita + releitura, com par surrogate na fronteira do bloco
    u16string s;
    for (int i = 0; i < 16383; ++i) s.push_back(u'a');
    s += u"\U0001F600";
    s += u"fim\u20ac";
    int fd = open(path.c_str(), O_WRONLY | O_TRUNC);
    int64_t w = write_fd_utf16(fd, s.data(), s.size());
    close(fd);
    CHECK(w == 16383 + 4 + 3 + 3);
    std::vector<char16_t> d(s.size() + 4);
    fd = open(path.c_str(), O_RDONLY);
    int64_t r = read_fd_utf16(fd, d.data(), d.size(), 1 << 20);
    close(fd);
    CHECK(r == static_cast<int64_t>(s.size()) && u16string(d.data(), r) == s);
  }
  unlink(path.c_str());
}

static void test_gap_buffer() {
  GapBuffer g(16);
  u16string ref;
  std::mt19937 rng(42);
  for (int it = 0; it < 20000; ++it) {
    if (ref.empty() || rng() % 3 != 0) {
      size_t pos = rng() % (ref.size() + 1), n = 1 + rng() % 40;
      u16string ins;
      for (size_t k = 0; k < n; ++k) ins.push_back(static_cast<char16_t>('a' + rng() % 26));
      g.insert(pos, ins.data(), n);
      ref.insert(pos, ins);
    } else {
      size_t pos = rng() % ref.size(), n = 1 + rng() % 30;
      g.erase(pos, n);
      ref.erase(pos, n);
    }
    if (it % 997 == 0) {
      std::vector<char16_t> out(ref.size() + 1);
      g.copy_to(0, ref.size(), out.data());
      CHECK(u16string(out.data(), ref.size()) == ref);
    }
  }
  CHECK(g.size() == ref.size());
  for (size_t i = 0; i < ref.size(); i += 17) CHECK(g[i] == ref[i]);
}

static LexOutput lexs(const char* s) {
  LexOutput o;
  u16string t = U(s);
  lex_python(t.data(), t.size(), o);
  return o;
}
static bool has_span(const LexOutput& o, int s, int e, int tok) {
  for (auto& x : o.spans)
    if (x.start == s && x.end == e && x.tok == tok) return true;
  return false;
}

static void test_lexer() {
  auto o = lexs("def foo(self):\n    return 1\n");
  CHECK(has_span(o, 0, 3, kKeyword));
  CHECK(has_span(o, 4, 7, kFunction));
  CHECK(has_span(o, 8, 12, kSelf));
  CHECK(has_span(o, 19, 25, kKeyword));
  CHECK(has_span(o, 26, 27, kNumber));
  CHECK(o.issues.empty());

  o = lexs("class A:\n    x = print('a\\'b') # c\n");
  CHECK(has_span(o, 6, 7, kClass));
  CHECK(has_span(o, 17, 22, kBuiltin));
  CHECK(has_span(o, 23, 29, kString));
  CHECK(o.issues.empty());

  o = lexs("x = f\"{a}\" + rb'raw'\n@dec.ator\ndef g(): pass\n");
  CHECK(has_span(o, 4, 10, kString));
  CHECK(has_span(o, 13, 20, kString));
  CHECK(has_span(o, 21, 30, kDecorator));

  o = lexs("s = 'abc\nz = 1\n");
  CHECK(o.issues.size() == 1 && o.issues[0].code == kUnterminatedString && o.issues[0].line == 1 && o.issues[0].col == 5);

  o = lexs("s = \"\"\"abc\nmore\n");
  CHECK(o.issues.size() == 1 && o.issues[0].code == kUnterminatedTriple && o.issues[0].aux == 3);
  CHECK(o.lines[1].inString == 1);

  o = lexs("x = (1, [2)\n");
  CHECK(o.issues.size() == 2);  // ")" não casa com "[" + "(" nunca fechado
  CHECK(o.issues[0].code == kMismatchedClose && o.issues[0].ch1 == ')' && o.issues[0].ch2 == '[');
  CHECK(o.issues[1].code == kNeverClosed && o.issues[1].ch1 == '(');

  o = lexs("a = 1)\n");
  CHECK(o.issues.size() == 1 && o.issues[0].code == kUnmatchedClose);

  o = lexs("x = 0xFF + 1e-5 + 3.14\nobj.def = 2\n");
  CHECK(has_span(o, 4, 8, kNumber) && has_span(o, 11, 15, kNumber) && has_span(o, 18, 22, kNumber));
  for (auto& s : o.spans) CHECK(!(s.tok == kKeyword && s.start == 23));  // "obj.def": atributo, não keyword

  o = lexs("f(\n  1,\n  2)\n");
  CHECK(o.lines[1].depthStart == 1 && o.lines[2].depthEnd == 0 && o.issues.empty());

  // fuzz: nunca quebra, spans ordenados e dentro do texto (rodar com ASAN/UBSAN)
  std::mt19937 rng(1);
  const char16_t alpha[] = u"abdefrcls\"'\\#()[]{}\n @.01xe+-_é😀\t ";
  LexOutput fo;
  for (int it = 0; it < 3000; ++it) {
    size_t n = rng() % 200;
    u16string t;
    for (size_t k = 0; k < n; ++k) t.push_back(alpha[rng() % (sizeof(alpha) / 2 - 1)]);
    lex_python(t.data(), t.size(), fo);
    int32_t prev = -1;
    for (auto& s : fo.spans) {
      CHECK(s.start >= prev && s.end >= s.start && s.end <= static_cast<int32_t>(n));
      prev = s.start;
    }
  }
}

static void test_queue_and_pool() {
  { // fila: capacidade e ordem
    MpmcQueue<int> q(4);
    for (int i = 0; i < 4; ++i) CHECK(q.try_push(int(i)));
    CHECK(!q.try_push(99));
    int v;
    for (int i = 0; i < 4; ++i) CHECK(q.try_pop(v) && v == i);
    CHECK(!q.try_pop(v));
  }
  { // MPMC: 4 produtores x 4 consumidores
    MpmcQueue<int> q(256);
    constexpr int kPer = 50000;
    std::atomic<long long> sum{0};
    std::atomic<int> got{0};
    std::vector<std::thread> th;
    for (int p = 0; p < 4; ++p)
      th.emplace_back([&] {
        for (int i = 1; i <= kPer; ++i) {
          int x = i;
          while (!q.try_push(std::move(x))) std::this_thread::yield();
        }
      });
    for (int c = 0; c < 4; ++c)
      th.emplace_back([&] {
        int v;
        while (got.load() < 4 * kPer) {
          if (q.try_pop(v)) { sum += v; ++got; } else std::this_thread::yield();
        }
      });
    for (auto& t : th) t.join();
    CHECK(sum.load() == 4LL * kPer * (kPer + 1) / 2);
  }
  { // pool: todas as tarefas rodam, inclusive as pendentes no stop()
    std::atomic<int> n{0};
    {
      ThreadPool pool(3, 64);
      int submitted = 0;
      for (int i = 0; i < 20000; ++i) {
        Task t([&n] { n.fetch_add(1, std::memory_order_relaxed); });
        while (!pool.submit(std::move(t))) std::this_thread::yield();
        ++submitted;
        if (i % 4096 == 0) std::this_thread::sleep_for(std::chrono::milliseconds(2));  // deixa workers dormirem
      }
      CHECK(submitted == 20000);
    }  // destrutor => stop() drena a fila
    CHECK(n.load() == 20000);
  }
  { // produtores concorrentes + workers que dormem/acordam
    std::atomic<int> n{0};
    ThreadPool pool(2, 128);
    std::vector<std::thread> prod;
    for (int p = 0; p < 3; ++p)
      prod.emplace_back([&] {
        for (int i = 0; i < 3000; ++i) {
          Task t([&n] { ++n; });
          while (!pool.submit(std::move(t))) std::this_thread::yield();
          if (i % 500 == 0) std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
      });
    for (auto& t : prod) t.join();
    pool.stop();
    CHECK(n.load() == 9000);
  }
}

static void test_scene() {
  Snapshot s;
  u16string t = U("def f():\n\tx = 'a b'\n\n# z\n");
  s.text.assign(t.begin(), t.end());
  s.lines.build(s.text.data(), s.text.size());
  lex_python(s.text.data(), s.text.size(), s.lex);
  AtlasInfo a;
  a.w = 160; a.h = 60; a.cols = 16; a.rows = 6; a.cellW = 10; a.cellH = 10;
  Theme th = default_theme();
  View v{200, 100, 0, 4, 4};
  std::vector<Vertex> verts(4 * 256);
  size_t q = build_scene(s, a, th, v, verts.data(), 256);
  // não-brancos: "def f():"=7, "x = 'a b'"= x,=,',a,b,' =6, "# z" = #,z =2 => 15
  CHECK(q == 15);
  CHECK(verts[0].x == 4 && verts[0].y == 0 && verts[1].x == 14);
  CHECK(verts[0].rgba == argb_to_rgba(th.tok[kKeyword]));
  // scroll: só 1ª linha fora da tela
  View v2{200, 20, 10, 4, 4};
  q = build_scene(s, a, th, v2, verts.data(), 256);
  CHECK(q == 8);  // linhas 1..3 visíveis: "\tx = 'a b'" (6) + vazia (0) + "# z" (2)
  CHECK(verts[0].y == 0);
  // limite de quads
  CHECK(build_scene(s, a, th, v, verts.data(), 3) == 3);
}


static void test_sha256() {
  CHECK(sha256_hex("") == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
  CHECK(sha256_hex("abc") == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  std::string big(1000000, 'a');  // vetor clássico: 1 milhão de 'a'
  CHECK(sha256_hex(big) == "cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0");
}

static void test_isolated() {
  IsoOptions o;
  {  // stdin -> stdout, exit code
    auto r = run_isolated([] { char b[64]; ssize_t n = read(0, b, sizeof b); for (ssize_t i = 0; i < n; ++i) b[i] = static_cast<char>(b[i] - 32); (void)!write(1, b, n); return 3; }, "abc", o);
    CHECK(r.exitCode == 3 && r.signal == 0 && r.output == "ABC" && !r.timedOut);
  }
  {  // printf com buffer total é descarregado no fim; stderr intercalado
    auto r = run_isolated([] { std::printf("oi"); std::fprintf(stderr, "!"); return 0; }, "", o);
    CHECK(r.exitCode == 0 && r.output.find("oi") != std::string::npos && r.output.find('!') != std::string::npos);
  }
  {  // crash do filho não afeta o pai
    auto r = run_isolated([]() -> int { std::abort(); }, "", o);
    CHECK(r.signal == SIGABRT);
  }
  {  // timeout mata o grupo
    IsoOptions t; t.timeoutMs = 150;
    auto r = run_isolated([] { sleep(5); return 0; }, "", t);
    CHECK(r.timedOut && r.signal == SIGKILL && r.micros < 2000000);
  }
  {  // laço infinito
    IsoOptions t; t.timeoutMs = 150;
    auto r = run_isolated([]() -> int { volatile unsigned long i = 0; for (;;) i = i + 1; }, "", t);
    CHECK(r.timedOut);
  }
  {  // limite de saída
    IsoOptions t; t.maxOutput = 1000;
    auto r = run_isolated([] { std::string s(100000, 'x'); (void)!write(1, s.data(), s.size()); return 0; }, "", t);
    CHECK(r.truncated && r.output.size() == 1000 && r.exitCode == 0);
  }
  {  // stdin grande (maior que o pipe) sem deadlock
    std::string in(300000, 'q');
    auto r = run_isolated([] { char b[4096]; size_t tot = 0; ssize_t n; while ((n = read(0, b, sizeof b)) > 0) tot += n; std::printf("%zu", tot); return 0; }, in, o);
    CHECK(r.output == "300000");
  }
  {  // cancelamento
    std::atomic<bool> cancel{false};
    IsoOptions t; t.cancel = &cancel; t.timeoutMs = 10000;
    std::thread th([&] { std::this_thread::sleep_for(std::chrono::milliseconds(100)); cancel = true; });
    auto r = run_isolated([] { sleep(5); return 0; }, "", t);
    th.join();
    CHECK(r.canceled && !r.timedOut && r.micros < 2000000);
  }
}

static CompileBackend gxx_backend() { return make_exec_backend("/tmp"); }

static void test_pipeline() {
  namespace fs = std::filesystem;
  const std::string root = "/tmp/ci_pipe_" + std::to_string(getpid());
  fs::remove_all(root);
  BuildConfig cfg;
  cfg.cacheDir = root + "/cache"; cfg.workDir = root + "/work"; cfg.toolchainId = "gxx-test";
  cfg.compiler = "g++"; cfg.pchExt = ".gch";
  cfg.compileFlags = {"-std=c++20", "-O0", "-fPIC"};
  cfg.linkFlags = {"-shared"};
  BuildPipeline bp(cfg, gxx_backend());

  const char* prog = "#include <iostream>\n#include <string>\nint main(int argc,char**argv){ std::string s; std::getline(std::cin,s); std::cout<<\"eco:\"<<s<<\" n=\"<<argc<<std::endl; return 7; }\n";
  auto b1 = bp.build(prog);
  CHECK(b1.ok && !b1.cacheHit && b1.compileUs > 0 && fs::exists(b1.soPath));
  auto run = run_isolated([&] { return run_so_main(b1.soPath, {"prog", "x"}); }, "ola\n", IsoOptions{});
  CHECK(run.exitCode == 7 && run.output == "eco:ola n=2\n");

  auto b2 = bp.build(prog);  // mesmo fonte: cache
  CHECK(b2.ok && b2.cacheHit && b2.soPath == b1.soPath && b2.compileUs == 0);
  auto b3 = bp.build(prog, {"-O1"});  // flags diferentes => outra chave
  CHECK(b3.ok && !b3.cacheHit && b3.soPath != b1.soPath);

  auto bad = bp.build("int main(){ return x; }\n");
  CHECK(!bad.ok && bad.log.find("error") != std::string::npos);

  {  // programa com crash: pai segue vivo
    auto b = bp.build("#include <cstdlib>\nint main(){ std::abort(); }\n");
    CHECK(b.ok);
    auto r = run_isolated([&] { return run_so_main(b.soPath, {}); }, "", IsoOptions{});
    CHECK(r.signal == SIGABRT);
  }
  {  // compilador inexistente (exec falha => 127, sem travar)
    BuildConfig c3 = cfg; c3.cacheDir = root + "/cache3"; c3.compiler = "/nao/existe/clang";
    BuildPipeline p3(c3, gxx_backend());
    auto b = p3.build("int main(){}\n");
    CHECK(!b.ok);
  }
  {  // timeout de compilação configurável por chamada (compilador simulado: sh -c "sleep 5")
    BuildConfig c4 = cfg; c4.cacheDir = root + "/cache4"; c4.compiler = "sh"; c4.compileFlags = {"-c", "sleep 5", "--"};
    c4.linkFlags = {};
    BuildPipeline p4(c4, gxx_backend());
    p4.set_compile_timeout_ms(150);
    auto b = p4.build("int main(){}\n");
    CHECK(!b.ok && b.timedOut && b.compileUs < 2000000);
  }
  {  // so inexistente
    auto r = run_isolated([] { return run_so_main("/nao/existe.so", {}); }, "", IsoOptions{});
    CHECK(r.exitCode == 127 && r.output.find("dlopen") != std::string::npos);
  }
  {  // PCH: constrói uma vez, reaproveita, e o programa continua compilando
    CHECK(bp.ensure_pch("#include <iostream>\n#include <vector>\n#include <string>\n"));
    CHECK(bp.ensure_pch("#include <iostream>\n#include <vector>\n#include <string>\n"));
    auto b = bp.build("int main(){ std::vector<int> v{1,2}; std::cout << v.size(); return 0; }\n");  // sem #include: vem do PCH
    CHECK(b.ok);
    auto r = run_isolated([&] { return run_so_main(b.soPath, {}); }, "", IsoOptions{});
    CHECK(r.exitCode == 0 && r.output == "2");
  }
  {  // despejo LRU: limite pequeno mantém só o mais novo
    BuildConfig c2 = cfg;
    c2.cacheDir = root + "/cache2"; c2.cacheMaxBytes = 1;
    BuildPipeline p2(c2, gxx_backend());
    auto a = p2.build("int main(){return 1;}\n");
    auto b = p2.build("int main(){return 2;}\n");
    CHECK(a.ok && b.ok && !fs::exists(a.soPath) && fs::exists(b.soPath));
  }
  fs::remove_all(root);
}

int main() {
  test_sha256();
  test_isolated();
  test_pipeline();
  test_utf();
  test_file_io();
  test_gap_buffer();
  test_lexer();
  test_queue_and_pool();
  test_scene();
  std::printf("%d checks, %d failures\n", g_checks, g_fail);
  return g_fail ? 1 : 0;
}
