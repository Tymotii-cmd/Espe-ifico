#include "render/renderer.hpp"

#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <android/log.h>
#include <pthread.h>

#include <chrono>

#define LOG_TAG "ci-render"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

#ifndef EGL_OPENGL_ES3_BIT_KHR
#define EGL_OPENGL_ES3_BIT_KHR 0x0040
#endif

namespace ci {
namespace {

constexpr size_t kMaxQuads = 16384;  // 16384*4 vértices = 65536 => índices de 16 bits bastam

constexpr const char* kVs = R"(#version 300 es
layout(location = 0) in vec2 aPos;
layout(location = 1) in vec2 aUV;
layout(location = 2) in vec4 aColor;
uniform vec2 uSize;  // 2/w, 2/h
out vec2 vUV;
out vec4 vColor;
void main() {
  gl_Position = vec4(aPos.x * uSize.x - 1.0, 1.0 - aPos.y * uSize.y, 0.0, 1.0);
  vUV = aUV;
  vColor = aColor;
})";

constexpr const char* kFs = R"(#version 300 es
precision highp float;
uniform sampler2D uAtlas;
in vec2 vUV;
in vec4 vColor;
out vec4 oColor;
void main() {
  oColor = vec4(vColor.rgb, vColor.a * texture(uAtlas, vUV).r);
})";

GLuint compile(GLenum type, const char* src) {
  GLuint s = glCreateShader(type);
  glShaderSource(s, 1, &src, nullptr);
  glCompileShader(s);
  GLint ok = 0;
  glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
  if (!ok) {
    char log[512];
    glGetShaderInfoLog(s, sizeof log, nullptr, log);
    LOGE("shader: %s", log);
    glDeleteShader(s);
    return 0;
  }
  return s;
}

inline EGLDisplay D(void* p) { return static_cast<EGLDisplay>(p); }

}  // namespace

Renderer::Renderer(SnapshotPool& pool) : pool_(pool), theme_(default_theme()) {
  verts_.reset(new Vertex[kMaxQuads * 4]);  // pré-alocado uma única vez
  thread_ = std::thread([this] { loop(); });
}

Renderer::~Renderer() {
  Event e;
  e.type = Ev::kQuit;
  post(e);
  thread_.join();
  Event d;
  while (q_.try_pop(d)) drop(d);
}

// ------------------------------------------------------------------ API (qualquer thread)
void Renderer::post(Event e) {
  const bool critical = e.type == Ev::kSurfaceCreated || e.type == Ev::kSurfaceDestroyed || e.type == Ev::kQuit;
  while (!q_.try_push(std::move(e))) {
    if (!critical) {
      drop(e);
      return;
    }
    std::this_thread::yield();
  }
  parker_.notify();
}

void Renderer::drop(const Event& e) {
  switch (e.type) {
    case Ev::kScene: pool_.release(static_cast<Snapshot*>(e.p)); break;
    case Ev::kAtlas: delete static_cast<AtlasData*>(e.p); break;
    case Ev::kSurfaceCreated: ANativeWindow_release(static_cast<ANativeWindow*>(e.p)); break;
    default: break;
  }
}

void Renderer::surface_created(ANativeWindow* w) {
  Event e; e.type = Ev::kSurfaceCreated; e.p = w; post(e);
}
void Renderer::surface_changed(int w, int h) {
  Event e; e.type = Ev::kSurfaceChanged; e.a = w; e.b = h; post(e);
}
void Renderer::surface_destroyed() {
  const uint32_t seq = destroySeq_.fetch_add(1) + 1;
  Event e; e.type = Ev::kSurfaceDestroyed; e.a = static_cast<int32_t>(seq); post(e);
  std::unique_lock<std::mutex> lk(ackMu_);
  // Timeout de segurança: nunca travar a UI thread (ANR) se a thread de render estiver presa no driver.
  if (!ackCv_.wait_for(lk, std::chrono::milliseconds(1500), [&] { return ackSeq_ >= seq; }))
    LOGE("surface_destroyed: timeout aguardando a thread de render");
}
void Renderer::set_paused(bool p) { Event e; e.type = Ev::kPause; e.a = p; post(e); }
void Renderer::set_scroll(float y) { Event e; e.type = Ev::kScroll; e.f = y; post(e); }
void Renderer::request_frame() { Event e; e.type = Ev::kFrame; post(e); }
void Renderer::set_atlas(std::unique_ptr<AtlasData> a) { Event e; e.type = Ev::kAtlas; e.p = a.release(); post(e); }
void Renderer::set_scene(Snapshot* s) { Event e; e.type = Ev::kScene; e.p = s; post(e); }

// ------------------------------------------------------------------ thread de render
void Renderer::loop() {
  pthread_setname_np(pthread_self(), "ci-render");
  while (!quit_) {
    Event ev;
    while (q_.try_pop(ev)) handle(ev);
    if (quit_) break;

    if (window_ && !paused_ && dirty_) {
      const bool ok = ensure_egl() && draw_frame();
      if (ok) {
        failCount_ = 0;
        continue;
      }
      release_egl();  // reconstrói tudo na próxima tentativa
      if (++failCount_ <= 50) {
        if (failCount_ > 1) parker_.wait_for(std::chrono::milliseconds(100));  // 1ª falha (ex.: context lost): retenta já
        continue;
      }
      LOGE("render: desistindo até o próximo evento");
      dirty_ = false;
      failCount_ = 0;
    }
    parker_.wait();
  }
  shutdown();
}

void Renderer::handle(const Event& e) {
  switch (e.type) {
    case Ev::kSurfaceCreated:
      release_egl();
      if (window_) ANativeWindow_release(window_);
      window_ = static_cast<ANativeWindow*>(e.p);
      dirty_ = true;
      break;
    case Ev::kSurfaceChanged:
      dirty_ = true;
      break;
    case Ev::kSurfaceDestroyed:
      release_egl();
      if (window_) {
        ANativeWindow_release(window_);
        window_ = nullptr;
      }
      {
        std::lock_guard<std::mutex> lk(ackMu_);
        ackSeq_ = static_cast<uint32_t>(e.a);
      }
      ackCv_.notify_all();
      break;
    case Ev::kPause:
      paused_ = e.a != 0;
      if (paused_) release_egl();  // libera GPU em background; volta do zero ao retomar
      else dirty_ = true;
      break;
    case Ev::kScroll:
      scroll_ = e.f < 0 ? 0 : e.f;
      dirty_ = true;
      break;
    case Ev::kAtlas:
      atlas_.reset(static_cast<AtlasData*>(e.p));
      atlasDirty_ = true;
      dirty_ = true;
      break;
    case Ev::kScene:
      if (current_) pool_.release(current_);
      current_ = static_cast<Snapshot*>(e.p);
      dirty_ = true;
      break;
    case Ev::kFrame:
      dirty_ = true;
      break;
    case Ev::kQuit:
      quit_ = true;
      break;
  }
}

// ------------------------------------------------------------------ EGL
bool Renderer::init_display() {
  if (dpy_) return true;
  EGLDisplay d = eglGetDisplay(EGL_DEFAULT_DISPLAY);
  if (d == EGL_NO_DISPLAY || !eglInitialize(d, nullptr, nullptr)) return false;
  const EGLint attrs[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT_KHR, EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
                          EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8,
                          EGL_DEPTH_SIZE, 0, EGL_STENCIL_SIZE, 0, EGL_NONE};
  EGLConfig cfg = nullptr;
  EGLint n = 0;
  if (!eglChooseConfig(d, attrs, &cfg, 1, &n) || n < 1) {
    LOGE("EGL: sem config ES3");
    eglTerminate(d);
    return false;
  }
  dpy_ = d;
  cfg_ = cfg;
  return true;
}

bool Renderer::ensure_egl() {
  if (!window_ || !init_display()) return false;
  EGLDisplay d = D(dpy_);
  EGLConfig cfg = static_cast<EGLConfig>(cfg_);
  if (!surf_) {
    EGLint fmt = 0;
    eglGetConfigAttrib(d, cfg, EGL_NATIVE_VISUAL_ID, &fmt);
    ANativeWindow_setBuffersGeometry(window_, 0, 0, fmt);
    surf_ = eglCreateWindowSurface(d, cfg, window_, nullptr);
    if (surf_ == EGL_NO_SURFACE) {
      surf_ = nullptr;
      LOGE("eglCreateWindowSurface: 0x%x", eglGetError());
      return false;
    }
  }
  if (!ctx_) {
    const EGLint ca[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    ctx_ = eglCreateContext(d, cfg, EGL_NO_CONTEXT, ca);
    if (ctx_ == EGL_NO_CONTEXT) {
      ctx_ = nullptr;
      LOGE("eglCreateContext: 0x%x", eglGetError());
      return false;
    }
  }
  if (!madeCurrent_) {
    if (!eglMakeCurrent(d, static_cast<EGLSurface>(surf_), static_cast<EGLSurface>(surf_), static_cast<EGLContext>(ctx_))) {
      LOGE("eglMakeCurrent: 0x%x", eglGetError());
      return false;
    }
    madeCurrent_ = true;
    eglSwapInterval(d, 1);
  }
  if (!glReady_) {
    glReady_ = create_gl();
    atlasDirty_ = true;
  }
  return glReady_;
}

// Destrói contexto + surface EGL + recursos GL. A janela (ANativeWindow) é mantida.
void Renderer::release_egl() {
  if (!dpy_) return;
  EGLDisplay d = D(dpy_);
  if (madeCurrent_ && glReady_) destroy_gl();
  glReady_ = false;
  eglMakeCurrent(d, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
  if (ctx_) eglDestroyContext(d, static_cast<EGLContext>(ctx_));
  if (surf_) eglDestroySurface(d, static_cast<EGLSurface>(surf_));
  ctx_ = nullptr;
  surf_ = nullptr;
  madeCurrent_ = false;
}

void Renderer::shutdown() {
  release_egl();
  if (dpy_) {
    eglTerminate(D(dpy_));
    dpy_ = nullptr;
  }
  if (window_) {
    ANativeWindow_release(window_);
    window_ = nullptr;
  }
  if (current_) {
    pool_.release(current_);
    current_ = nullptr;
  }
}

// ------------------------------------------------------------------ GL
bool Renderer::create_gl() {
  GLuint vs = compile(GL_VERTEX_SHADER, kVs), fs = compile(GL_FRAGMENT_SHADER, kFs);
  if (!vs || !fs) {
    if (vs) glDeleteShader(vs);
    if (fs) glDeleteShader(fs);
    return false;
  }
  program_ = glCreateProgram();
  glAttachShader(program_, vs);
  glAttachShader(program_, fs);
  glLinkProgram(program_);
  glDeleteShader(vs);
  glDeleteShader(fs);
  GLint ok = 0;
  glGetProgramiv(program_, GL_LINK_STATUS, &ok);
  if (!ok) {
    LOGE("link falhou");
    glDeleteProgram(program_);
    program_ = 0;
    return false;
  }
  uSize_ = glGetUniformLocation(program_, "uSize");
  uAtlas_ = glGetUniformLocation(program_, "uAtlas");

  // IBO estático: padrão de 2 triângulos por quad.
  std::unique_ptr<uint16_t[]> idx(new uint16_t[kMaxQuads * 6]);
  for (size_t i = 0; i < kMaxQuads; ++i) {
    const uint16_t b = static_cast<uint16_t>(i * 4);
    uint16_t* p = idx.get() + i * 6;
    p[0] = b; p[1] = b + 1; p[2] = b + 2; p[3] = b + 2; p[4] = b + 1; p[5] = b + 3;
  }
  glGenVertexArrays(1, &vao_);
  glGenBuffers(1, &vbo_);
  glGenBuffers(1, &ibo_);
  glBindVertexArray(vao_);
  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo_);
  glBufferData(GL_ELEMENT_ARRAY_BUFFER, kMaxQuads * 6 * sizeof(uint16_t), idx.get(), GL_STATIC_DRAW);
  glBindBuffer(GL_ARRAY_BUFFER, vbo_);
  glEnableVertexAttribArray(0);
  glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), reinterpret_cast<void*>(offsetof(Vertex, x)));
  glEnableVertexAttribArray(1);
  glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), reinterpret_cast<void*>(offsetof(Vertex, u)));
  glEnableVertexAttribArray(2);
  glVertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(Vertex), reinterpret_cast<void*>(offsetof(Vertex, rgba)));
  glBindVertexArray(0);

  glGenTextures(1, &tex_);
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glDisable(GL_DEPTH_TEST);
  return true;
}

void Renderer::destroy_gl() {
  if (tex_) glDeleteTextures(1, &tex_);
  if (vbo_) glDeleteBuffers(1, &vbo_);
  if (ibo_) glDeleteBuffers(1, &ibo_);
  if (vao_) glDeleteVertexArrays(1, &vao_);
  if (program_) glDeleteProgram(program_);
  tex_ = vbo_ = ibo_ = vao_ = program_ = 0;
}

void Renderer::upload_atlas() {
  atlasDirty_ = false;
  if (!atlas_ || atlas_->info.w <= 0) return;
  glBindTexture(GL_TEXTURE_2D, tex_);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  glPixelStorei(GL_UNPACK_ROW_LENGTH, atlas_->stride);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_R8, atlas_->info.w, atlas_->info.h, 0, GL_RED, GL_UNSIGNED_BYTE, atlas_->pixels.data());
  glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
}

bool Renderer::draw_frame() {
  EGLDisplay d = D(dpy_);
  EGLSurface s = static_cast<EGLSurface>(surf_);
  EGLint w = 0, h = 0;
  eglQuerySurface(d, s, EGL_WIDTH, &w);
  eglQuerySurface(d, s, EGL_HEIGHT, &h);
  if (w <= 0 || h <= 0) {
    dirty_ = false;
    return true;  // surface ainda sem tamanho: espera o próximo evento
  }
  if (atlasDirty_) upload_atlas();

  glViewport(0, 0, w, h);
  const uint32_t bg = argb_to_rgba(theme_.bg);
  glClearColor((bg & 0xFF) / 255.f, ((bg >> 8) & 0xFF) / 255.f, ((bg >> 16) & 0xFF) / 255.f, 1.f);
  glClear(GL_COLOR_BUFFER_BIT);

  if (current_ && atlas_ && atlas_->info.w > 0) {
    const View v{static_cast<float>(w), static_cast<float>(h), scroll_, 8.f, 4};
    const size_t quads = build_scene(*current_, atlas_->info, theme_, v, verts_.get(), kMaxQuads);
    if (quads) {
      glBindVertexArray(vao_);
      glBindBuffer(GL_ARRAY_BUFFER, vbo_);
      // glBufferData com dados = "orphan + upload" numa chamada: o driver não espera a GPU soltar o frame anterior.
      glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(quads * 4 * sizeof(Vertex)), verts_.get(), GL_STREAM_DRAW);
      glUseProgram(program_);
      glUniform2f(uSize_, 2.f / static_cast<float>(w), 2.f / static_cast<float>(h));
      glActiveTexture(GL_TEXTURE0);
      glBindTexture(GL_TEXTURE_2D, tex_);
      glUniform1i(uAtlas_, 0);
      glDrawElements(GL_TRIANGLES, static_cast<GLsizei>(quads * 6), GL_UNSIGNED_SHORT, nullptr);
      glBindVertexArray(0);
    }
  }

  if (!eglSwapBuffers(d, s)) {
    const EGLint err = eglGetError();
    LOGW("eglSwapBuffers falhou: 0x%x", err);
    if (err == EGL_BAD_NATIVE_WINDOW && window_) {  // janela morta: espera uma nova surface
      release_egl();
      ANativeWindow_release(window_);
      window_ = nullptr;
      return true;
    }
    dirty_ = true;  // EGL_CONTEXT_LOST / BAD_SURFACE: o chamador chama release_egl() e recria
    return false;
  }
  dirty_ = false;
  return true;
}

}  // namespace ci
