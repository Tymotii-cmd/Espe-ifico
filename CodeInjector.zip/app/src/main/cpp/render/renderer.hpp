#pragma once
// Renderer OpenGL ES 3.0 sobre ANativeWindow/EGL, numa thread própria, orientado a eventos.
//
// Regras de resiliência:
//  * TODO estado de GPU é derivado de estado de CPU (atlas, snapshot). Perdeu o contexto,
//    foi pausado ou a surface morreu => destrói tudo e reconstrói do zero no próximo frame.
//  * surface_destroyed() é síncrono: ao retornar, a thread de render já largou a janela.
//  * Só desenha sob demanda (dirty flag); eglSwapInterval(1) faz o pacing no vsync.
#include <android/native_window.h>

#include <atomic>
#include <condition_variable>
#include <memory>
#include <mutex>
#include <thread>
#include <vector>

#include "core/mpmc_queue.hpp"
#include "core/parker.hpp"
#include "scene/scene_builder.hpp"

namespace ci {

struct AtlasData {
  AtlasInfo info;
  int stride = 0;  // bytes por linha em `pixels`
  std::vector<uint8_t> pixels;
};

class Renderer {
 public:
  explicit Renderer(SnapshotPool& pool);
  ~Renderer();
  Renderer(const Renderer&) = delete;
  Renderer& operator=(const Renderer&) = delete;

  // Todas thread-safe; nenhuma bloqueia, exceto surface_destroyed().
  void surface_created(ANativeWindow* window);  // assume 1 referência (ANativeWindow_fromSurface)
  void surface_changed(int w, int h);
  void surface_destroyed();
  void set_paused(bool paused);
  void set_scroll(float y);
  void set_atlas(std::unique_ptr<AtlasData> atlas);
  void set_scene(Snapshot* s);  // assume a posse; devolve ao pool quando substituído
  void request_frame();

 private:
  enum class Ev : uint8_t { kSurfaceCreated, kSurfaceChanged, kSurfaceDestroyed, kPause, kScroll, kAtlas, kScene, kFrame, kQuit };
  struct Event {
    Ev type = Ev::kFrame;
    int32_t a = 0, b = 0;
    float f = 0;
    void* p = nullptr;
  };

  void post(Event e);
  void drop(const Event& e);
  void loop();
  void handle(const Event& e);

  bool init_display();
  bool ensure_egl();
  void release_egl();
  bool create_gl();
  void destroy_gl();
  void upload_atlas();
  bool draw_frame();
  void shutdown();

  SnapshotPool& pool_;
  MpmcQueue<Event> q_{1024};
  Parker parker_;
  std::thread thread_;

  // sincronização do ack de surface_destroyed()
  std::mutex ackMu_;
  std::condition_variable ackCv_;
  uint32_t ackSeq_ = 0;
  std::atomic<uint32_t> destroySeq_{0};

  // ---- estado exclusivo da thread de render ----
  ANativeWindow* window_ = nullptr;
  void* dpy_ = nullptr;      // EGLDisplay
  void* cfg_ = nullptr;      // EGLConfig
  void* surf_ = nullptr;     // EGLSurface
  void* ctx_ = nullptr;      // EGLContext
  bool madeCurrent_ = false, glReady_ = false, dirty_ = false, paused_ = false, quit_ = false;
  int failCount_ = 0;
  float scroll_ = 0;
  Theme theme_;
  Snapshot* current_ = nullptr;
  std::unique_ptr<AtlasData> atlas_;
  bool atlasDirty_ = false;
  std::unique_ptr<Vertex[]> verts_;
  unsigned program_ = 0, vao_ = 0, vbo_ = 0, ibo_ = 0, tex_ = 0;
  int uSize_ = -1, uAtlas_ = -1;
};

}  // namespace ci
