package com.dev.codeinjector.nativecore

/** Preencha depois de publicar o pacote de sysroot (tools/make_sysroot_pack.sh). URL vazia = sem botão de download. */
object ToolchainConfig {
    const val ID = "llvm-android-1"
    const val URL = ""
    const val SHA256 = ""
    const val SIZE_BYTES = 0L
    val manifest get() = ToolchainManifest(ID, URL, SHA256, SIZE_BYTES)
}
