package com.dev.codeinjector

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch

enum class SymKind { KEYWORD, FUNCTION, CLASS, VARIABLE, BUILTIN, MODULE, ATTRIBUTE }

/** [insert] substitui o prefixo digitado; o cursor termina [cursorBack] caracteres antes do fim do texto inserido. */
data class Suggestion(val label: String, val insert: String, val cursorBack: Int, val kind: SymKind)

/** Extrai nomes declarados no arquivo .py atual e monta as sugestões (estilo teclado de celular). */
object PySymbols {
    private class Sym(val name: String, val kind: SymKind, val hasParams: Boolean = false, val order: Int)
    private class Index(val syms: List<Sym>, val attrs: List<String>, val selfAttrs: List<String>)

    private val DEF = Regex("(?m)^[ \\t]*(?:async[ \\t]+)?def[ \\t]+([A-Za-z_]\\w*)[ \\t]*\\(([^)\\n]*)")
    private val CLS = Regex("(?m)^[ \\t]*class[ \\t]+([A-Za-z_]\\w*)")
    private val ASSIGN = Regex("(?m)^[ \\t]*([A-Za-z_]\\w*(?:[ \\t]*,[ \\t]*[A-Za-z_]\\w*)*)[ \\t]*(?:[-+*/%&|^@]|//|\\*\\*|<<|>>)?=(?!=)")
    private val FOR = Regex("(?m)\\bfor[ \\t]+([A-Za-z_]\\w*(?:[ \\t]*,[ \\t]*[A-Za-z_]\\w*)*)[ \\t]+in\\b")
    private val AS = Regex("\\bas[ \\t]+([A-Za-z_]\\w*)")
    private val IMPORT = Regex("(?m)^[ \\t]*import[ \\t]+([^\\n#]+)")
    private val FROM = Regex("(?m)^[ \\t]*from[ \\t]+[\\w.]+[ \\t]+import[ \\t]+([^\\n#]+)")
    private val ATTR = Regex("\\.([A-Za-z_]\\w*)")
    private val SELF_ATTR = Regex("\\bself\\.([A-Za-z_]\\w*)")
    private val ID = Regex("[A-Za-z_]\\w*")

    @Volatile private var cache: Pair<String, Index>? = null

    private fun index(text: String): Index {
        cache?.let { if (it.first == text) return it.second }
        val found = LinkedHashMap<String, Sym>()
        var order = 0
        fun add(name: String, kind: SymKind, params: Boolean = false) {
            if (name in SyntaxAnalyzer.KEYWORDS || name.length < 2 && kind == SymKind.VARIABLE) return
            found[name] = Sym(name, kind, params, order++)
        }
        DEF.findAll(text).forEach { m ->
            val ps = m.groupValues[2].split(',').map { it.trim().removePrefix("**").removePrefix("*").substringBefore(':').substringBefore('=').trim() }
                .filter { it.isNotEmpty() && it != "self" && it != "cls" && it != "/" }
            add(m.groupValues[1], SymKind.FUNCTION, ps.isNotEmpty())
            ps.forEach { add(it, SymKind.VARIABLE) }
        }
        CLS.findAll(text).forEach { add(it.groupValues[1], SymKind.CLASS) }
        ASSIGN.findAll(text).forEach { m -> m.groupValues[1].split(',').forEach { add(it.trim(), SymKind.VARIABLE) } }
        FOR.findAll(text).forEach { m -> m.groupValues[1].split(',').forEach { add(it.trim(), SymKind.VARIABLE) } }
        AS.findAll(text).forEach { add(it.groupValues[1], SymKind.VARIABLE) }
        IMPORT.findAll(text).forEach { m ->
            m.groupValues[1].split(',').forEach { part ->
                val p = part.trim()
                add(if (" as " in p) p.substringAfter(" as ").trim() else p.substringBefore('.').trim(), SymKind.MODULE)
            }
        }
        FROM.findAll(text).forEach { m ->
            m.groupValues[1].replace("(", "").replace(")", "").split(',').forEach { part ->
                val p = part.trim()
                val n = if (" as " in p) p.substringAfter(" as ").trim() else p
                if (ID.matches(n)) add(n, SymKind.VARIABLE)
            }
        }
        val attrs = ATTR.findAll(text).map { it.groupValues[1] }.distinct().toList()
        val selfAttrs = SELF_ATTR.findAll(text).map { it.groupValues[1] }.distinct().toList()
        return Index(found.values.toList(), attrs, selfAttrs).also { cache = text to it }
    }

    private val STARTERS = listOf("def", "class", "import", "return", "self", "if", "elif", "else", "try", "except", "for", "while", "from", "print")
    private val INLINE = listOf("self", "True", "False", "None", "and", "or", "not", "in", "len", "range", "print")

    private fun kwInsert(w: String): Pair<String, Int> = when (w) {
        "def", "class", "import", "return", "if", "elif", "while", "for", "with", "lambda", "from", "not", "and", "or", "in", "is",
        "raise", "assert", "del", "global", "nonlocal", "yield", "await", "except", "as" -> "$w " to 0
        "else", "try", "finally" -> "$w:" to 0
        else -> w to 0
    }

    private fun make(name: String, kind: SymKind, hasParams: Boolean): Suggestion = when (kind) {
        SymKind.KEYWORD -> kwInsert(name).let { Suggestion(name, it.first, it.second, kind) }
        SymKind.FUNCTION -> Suggestion(name, "$name()", if (hasParams) 1 else 0, kind)
        SymKind.CLASS -> Suggestion(name, "$name()", 1, kind)
        SymKind.BUILTIN -> if (name in SyntaxAnalyzer.BUILTIN_FUNCS) Suggestion(name, "$name()", 1, kind) else Suggestion(name, name, 0, kind)
        else -> Suggestion(name, name, 0, kind)
    }

    class MemberQuery(val prefix: String, val line: Int, val col: Int)

    /** Se o cursor está logo depois de "algo." (com ou sem prefixo), devolve onde perguntar ao Python. */
    fun memberQuery(text: String, cursor: Int): MemberQuery? {
        val cp = cursor.coerceIn(0, text.length)
        var p = cp
        while (p > 0 && (text[p - 1].isLetterOrDigit() || text[p - 1] == '_')) p--
        if (p == 0 || text[p - 1] != '.') return null
        var line = 1; var ls = 0
        for (i in 0 until p) if (text[i] == '\n') { line++; ls = i + 1 }
        return MemberQuery(text.substring(p, cp), line, p - ls)
    }

    /** Retorna (prefixo antes do cursor, sugestões ordenadas). */
    fun suggest(text: String, cursor: Int, limit: Int = 14): Pair<String, List<Suggestion>> {
        val cp = cursor.coerceIn(0, text.length)
        val prefix = text.substring(0, cp).takeLastWhile { it.isLetterOrDigit() || it == '_' }
        val before = text.substring(0, cp - prefix.length)
        val lineBefore = before.substringAfterLast('\n')
        val idx = index(text)
        val out = ArrayList<Suggestion>()

        if (before.endsWith(".")) {
            val isSelf = before.endsWith("self.")
            val pool = (if (isSelf) idx.selfAttrs + idx.syms.filter { it.kind == SymKind.FUNCTION }.map { it.name } else idx.attrs).distinct()
            pool.filter { it != prefix && it.startsWith(prefix, ignoreCase = true) }.sortedBy { it.length }.take(limit).forEach {
                val isFn = idx.syms.any { s -> s.name == it && s.kind == SymKind.FUNCTION }
                out += if (isFn) make(it, SymKind.FUNCTION, idx.syms.first { s -> s.name == it }.hasParams) else Suggestion(it, it, 0, SymKind.ATTRIBUTE)
            }
            return prefix to out
        }

        if (prefix.isEmpty()) {
            val atLineStart = lineBefore.isBlank()
            val declared = idx.syms.sortedByDescending { it.order }.take(8).map { make(it.name, it.kind, it.hasParams) }
            val kws = (if (atLineStart) STARTERS else INLINE).map {
                if (it in SyntaxAnalyzer.KEYWORDS) make(it, SymKind.KEYWORD, false) else make(it, SymKind.BUILTIN, false)
            }
            out += if (atLineStart) kws + declared else declared + kws
            return prefix to out.distinctBy { it.kind.name + it.label }.take(limit)
        }

        class Cand(val s: Suggestion, val rank: Int)
        val cands = ArrayList<Cand>()
        idx.syms.forEach { if (it.name != prefix) cands += Cand(make(it.name, it.kind, it.hasParams), if (it.name.startsWith(prefix)) 0 else 1) }
        SyntaxAnalyzer.KEYWORDS.forEach { cands += Cand(make(it, SymKind.KEYWORD, false), 2) }
        (SyntaxAnalyzer.BUILTIN_FUNCS + SyntaxAnalyzer.BUILTIN_OTHERS).forEach { cands += Cand(make(it, SymKind.BUILTIN, false), 3) }
        var hits = cands.filter { it.s.label.length > prefix.length && it.s.label.startsWith(prefix, ignoreCase = true) }
        if (hits.size < 3 && prefix.length >= 2)
            hits = hits + cands.filter { it.s.label.contains(prefix, ignoreCase = true) && !it.s.label.startsWith(prefix, ignoreCase = true) }
        hits.sortedWith(compareBy({ it.rank }, { it.s.label.length })).forEach { out += it.s }
        return prefix to out.distinctBy { it.kind.name + it.label }.take(limit)
    }
}

private fun kindColor(k: SymKind, t: CodeTheme): Color = when (k) {
    SymKind.KEYWORD -> t.keyword
    SymKind.FUNCTION -> t.function
    SymKind.CLASS -> t.className
    SymKind.BUILTIN -> t.builtin
    SymKind.MODULE -> t.decorator
    SymKind.VARIABLE, SymKind.ATTRIBUTE -> t.text
}

/**
 * Barra acima do teclado: linha 1 = sugestões (LazyRow, estilo dicionário do celular);
 * linha 2 = desindentar, tab, desfazer/refazer e setas; linha 3 = selecionar (arrastar), tudo, copiar, cortar, colar, apagar.
 */
@Composable
fun KeyboardSuggestionBar(
    text: String, cursor: Int, theme: CodeTheme,
    canUndo: Boolean, canRedo: Boolean,
    onSuggestion: (prefixLen: Int, insert: String, cursorBack: Int) -> Unit,
    onUndo: () -> Unit, onRedo: () -> Unit,
    onMove: (dx: Int, dy: Int) -> Unit, onTab: () -> Unit, onOutdent: () -> Unit,
    selectMode: Boolean, onToggleSelect: () -> Unit,
    onSelectAll: () -> Unit, onCut: () -> Unit,
    onCopy: () -> Unit, onPaste: () -> Unit, onDelete: () -> Unit,
    members: List<MemberSug> = emptyList(),
    modifier: Modifier = Modifier
) {
    // prefixo barato (síncrono); o índice de símbolos (várias regex no arquivo todo) roda fora da thread principal
    val prefix = remember(text, cursor) {
        val cp = cursor.coerceIn(0, text.length)
        var p = cp
        while (p > 0 && (text[p - 1].isLetterOrDigit() || text[p - 1] == '_')) p--
        text.substring(p, cp)
    }
    val computed by produceState(initialValue = emptyList<Suggestion>(), text, cursor) {
        delay(80)
        value = withContext(Dispatchers.Default) { PySymbols.suggest(text, cursor).second }
    }
    val base = computed
    val suggestions = remember(base, members, prefix) {
        if (members.isEmpty()) base else {
            val m = members
                .filter { it.name != prefix && (prefix.isEmpty() || it.name.startsWith(prefix, ignoreCase = true)) }
                .let { if (prefix.isEmpty()) it else it.sortedBy { x -> x.name.length } }
                .take(30)
                .map {
                    when (it.kind) {
                        "f" -> Suggestion(it.name, it.name + "()", if (it.hasParams) 1 else 0, SymKind.FUNCTION)
                        "c" -> Suggestion(it.name, it.name + "()", 1, SymKind.CLASS)
                        "m" -> Suggestion(it.name, it.name, 0, SymKind.MODULE)
                        else -> Suggestion(it.name, it.name, 0, SymKind.ATTRIBUTE)
                    }
                }
            (m + base).distinctBy { it.label }.take(40)
        }
    }
    Column(modifier.fillMaxWidth().background(theme.bar)) {
        LazyRow(
            Modifier.fillMaxWidth().height(40.dp),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(suggestions, key = { it.kind.name + it.label }) { s ->
                Box(
                    Modifier.clip(RoundedCornerShape(16.dp)).background(theme.chip)
                        .pointerInput(s, prefix) { detectTapGestures { onSuggestion(prefix.length, s.insert, s.cursorBack) } }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val tag = when (s.kind) { SymKind.FUNCTION -> "ƒ "; SymKind.CLASS -> "C "; SymKind.MODULE -> "▣ "; else -> "" }
                    Text(tag + s.label, color = kindColor(s.kind, theme), fontSize = 14.sp, fontFamily = FontFamily.Monospace, maxLines = 1)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            KeyButton("⇤", theme, Modifier.weight(1f)) { onOutdent() }
            KeyButton("⇥", theme, Modifier.weight(1f)) { onTab() }
            KeyButton("↶", theme, Modifier.weight(1f), enabled = canUndo) { onUndo() }
            KeyButton("↷", theme, Modifier.weight(1f), enabled = canRedo) { onRedo() }
            KeyButton("←", theme, Modifier.weight(1f), repeat = true) { onMove(-1, 0) }
            KeyButton("↑", theme, Modifier.weight(1f), repeat = true) { onMove(0, -1) }
            KeyButton("↓", theme, Modifier.weight(1f), repeat = true) { onMove(0, 1) }
            KeyButton("→", theme, Modifier.weight(1f), repeat = true) { onMove(1, 0) }
        }
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, bottom = 3.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            KeyButton("Selecionar", theme, Modifier.weight(1.6f), label = 12, active = selectMode) { onToggleSelect() }
            KeyButton("Tudo", theme, Modifier.weight(1f), label = 12) { onSelectAll() }
            KeyButton("Copiar", theme, Modifier.weight(1.2f), label = 12) { onCopy() }
            KeyButton("Cortar", theme, Modifier.weight(1.2f), label = 12) { onCut() }
            KeyButton("Colar", theme, Modifier.weight(1f), label = 12) { onPaste() }
            KeyButton("Apagar", theme, Modifier.weight(1.2f), label = 12) { onDelete() }
        }
    }
}

@Composable
private fun KeyButton(
    text: String, theme: CodeTheme, modifier: Modifier = Modifier,
    enabled: Boolean = true, repeat: Boolean = false, label: Int = 20, active: Boolean = false, onClick: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val cb by rememberUpdatedState(onClick)
    Box(
        modifier.height(40.dp)
            .alpha(if (enabled) 1f else 0.35f)
            .clip(RoundedCornerShape(10.dp)).background(if (active) theme.function.copy(alpha = 0.4f) else theme.chip)
            .pointerInput(enabled, repeat) {
                detectTapGestures(
                    onPress = {
                        if (enabled && repeat) {
                            val job = scope.launch { cb(); delay(380); while (true) { cb(); delay(55) } }
                            tryAwaitRelease(); job.cancel()
                        }
                    },
                    onTap = { if (enabled && !repeat) cb() }
                )
            },
        contentAlignment = Alignment.Center
    ) { Text(text, color = theme.text, fontSize = label.sp, fontFamily = FontFamily.Monospace, maxLines = 1) }
}
