package com.dev.codeinjector.nativecore

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Ponte para libcodeinjector_native.so. Todos os dados grandes trafegam em ByteBuffer DIRETO
 * (alocado com [newBuffer]); as funções `n*` são registradas por RegisterNatives no JNI_OnLoad.
 *
 * Se a biblioteca não carregar, [available] fica false e o app segue funcionando sem o motor nativo.
 */
object NativeCore {
    /** Chamado numa thread do pool nativo (já anexada à JVM). Não bloqueie; despache para a main se precisar. */
    interface Listener {
        /** spanCount < 0 => análise descartada por uma requisição mais nova. */
        fun onAnalysisDone(requestId: Long, spanCount: Int, issueCount: Int, truncated: Boolean)
    }

    /** Resultado de compilar+executar. Chamado numa thread nativa. */
    interface ExecListener {
        fun onExecDone(requestId: Long, status: Int, exitCode: Int, cacheHit: Boolean, compileUs: Long, runUs: Long, output: String)
    }

    const val ERR_IO = -1L
    const val ERR_BINARY = -2L
    const val ERR_TOO_LARGE = -3L
    const val ERR_CAPACITY = -4L

    @Volatile
    var available: Boolean = false
        private set

    init {
        available = try {
            System.loadLibrary("codeinjector_native"); true
        } catch (_: UnsatisfiedLinkError) {
            false
        }
    }

    /** Buffer direto na ordem nativa (necessário para asCharBuffer/asIntBuffer baterem com o C++). */
    fun newBuffer(bytes: Int): ByteBuffer = ByteBuffer.allocateDirect(bytes).order(ByteOrder.nativeOrder())

    /** Copia [s] (UTF-16) para o início de [buf]. Retorna o nº de chars ou -1 se não couber. */
    fun putText(buf: ByteBuffer, s: String): Int {
        if (s.length * 2 > buf.capacity()) return -1
        buf.clear()
        buf.asCharBuffer().put(s)
        return s.length
    }

    /** Cria o motor (pool de threads + renderer). Idempotente. threads <= 0 => automático. */
    fun start(threads: Int, listener: Listener) { if (available) nInit(threads, listener) }

    @JvmStatic external fun nInit(threads: Int, listener: Listener)
    @JvmStatic external fun nShutdown()

    /** Lê o arquivo do fd (emprestado, não é fechado) direto para [dst] em UTF-16. capChars >= tamanho em bytes. */
    @JvmStatic external fun nReadFile(fd: Int, dst: ByteBuffer, capChars: Int, maxBytes: Int): Long
    @JvmStatic external fun nWriteFile(fd: Int, src: ByteBuffer, lenChars: Int): Long

    /** Layout de [out]: ver NativeAnalyzer. [src] pode ser reutilizado assim que a chamada retorna. */
    @JvmStatic external fun nAnalyzeAsync(src: ByteBuffer, lenChars: Int, out: ByteBuffer, requestId: Long, publish: Boolean): Boolean

    @JvmStatic external fun nSurfaceCreated(surface: android.view.Surface)
    @JvmStatic external fun nSurfaceChanged(width: Int, height: Int)
    @JvmStatic external fun nSurfaceDestroyed()
    @JvmStatic external fun nSetAtlas(pixels: ByteBuffer, w: Int, h: Int, stride: Int, cols: Int, rows: Int, cellW: Int, cellH: Int)
    @JvmStatic external fun nSetScroll(y: Float)
    @JvmStatic external fun nSetPaused(paused: Boolean)
    @JvmStatic external fun nRequestFrame()

    // ---- compilar C++ e executar (toolchain baixado) ----
    /**
     * clangPath/ldPath não vazios => modo EXECUTÁVEL (clang e ld.lld como processos).
     * Vazios => modo BIBLIOTECA (toolchainDir/libci_clang_host.so). false se o toolchain não é utilizável.
     */
    @JvmStatic external fun nExecInit(
        toolchainDir: String, clangPath: String, ldPath: String, cacheDir: String, workDir: String,
        toolchainId: String, pchHeader: String, listener: ExecListener,
    ): Boolean
    /** flags: uma por linha. false se já há uma execução em curso. */
    @JvmStatic external fun nBuildAndRun(source: String, stdin: String, flags: String, compileTimeoutMs: Int, runTimeoutMs: Int, requestId: Long): Boolean
    @JvmStatic external fun nExecCancel()
    @JvmStatic external fun nExecShutdown()
}
