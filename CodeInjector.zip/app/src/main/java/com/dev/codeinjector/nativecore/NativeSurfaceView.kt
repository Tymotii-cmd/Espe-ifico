package com.dev.codeinjector.nativecore

import android.content.Context
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View

/**
 * SurfaceView cujo Surface vira ANativeWindow no C++. Ciclo de vida:
 *  - surfaceDestroyed bloqueia até o renderer largar a janela (exigência do Android);
 *  - ao esconder/bloquear a tela o renderer libera EGL/GL e reconstrói tudo ao voltar.
 */
class NativeSurfaceView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {
    private var scrollPx = 0f
    var maxScroll = Float.MAX_VALUE

    private val detector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            scrollPx = (scrollPx + dy).coerceIn(0f, maxScroll)
            if (NativeCore.available) NativeCore.nSetScroll(scrollPx)
            return true
        }
    })

    init { holder.addCallback(this) }

    override fun surfaceCreated(h: SurfaceHolder) { if (NativeCore.available) NativeCore.nSurfaceCreated(h.surface) }
    override fun surfaceChanged(h: SurfaceHolder, format: Int, w: Int, hgt: Int) { if (NativeCore.available) NativeCore.nSurfaceChanged(w, hgt) }
    override fun surfaceDestroyed(h: SurfaceHolder) { if (NativeCore.available) NativeCore.nSurfaceDestroyed() }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (NativeCore.available) NativeCore.nSetPaused(visibility != View.VISIBLE)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean = detector.onTouchEvent(event) || super.onTouchEvent(event)
}
