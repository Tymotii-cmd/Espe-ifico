package com.dev.codeinjector.nativecore

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.zip.ZipInputStream

/** Pacote do toolchain: sysroot/ + clang-resource/ (e opcionalmente libci_clang_host.so). Ver README_TOOLCHAIN.md. `sha256` em hexadecimal minúsculo. */
class ToolchainManifest(val id: String, val url: String, val sha256: String, val sizeBytes: Long)

/**
 * Baixa, verifica (SHA-256) e instala o toolchain em filesDir/toolchain/<id>/.
 * Download retomável (Range), extração com proteção contra zip-slip, instalação atômica (rename) e
 * arquivos somente leitura (exigência do Android 14 para código carregado dinamicamente).
 * Funções bloqueantes: chame de Dispatchers.IO.
 */
class ToolchainManager(ctx: Context) {
    private val root = File(ctx.filesDir, "toolchain")

    fun installedDir(id: String): File? =
        File(root, id).takeIf { File(it, ".complete").exists() && File(it, "sysroot/usr/include").isDirectory }

    fun install(m: ToolchainManifest, onProgress: (done: Long, total: Long) -> Unit = { _, _ -> }): File {
        installedDir(m.id)?.let { return it }
        root.mkdirs()
        require(root.usableSpace > m.sizeBytes * 3) { "espaço insuficiente (precisa de ~${m.sizeBytes * 3 / (1 shl 20)} MB livres)" }

        val zip = File(root, "${m.id}.zip.part")
        download(m, zip, onProgress)
        val digest = sha256(zip)
        if (!digest.equals(m.sha256, ignoreCase = true)) { zip.delete(); error("SHA-256 não confere: pacote corrompido ou adulterado") }

        val tmp = File(root, "${m.id}.tmp").also { it.deleteRecursively(); it.mkdirs() }
        unzip(zip, tmp)
        File(tmp, "sysroot/usr/include").takeIf { it.isDirectory } ?: error("pacote sem sysroot/usr/include")
        File(tmp, ".complete").writeText(m.sha256)
        tmp.walkTopDown().filter { it.isFile }.forEach { it.setReadOnly() }

        val dest = File(root, m.id).also { it.deleteRecursively() }
        check(tmp.renameTo(dest)) { "falha ao finalizar a instalação" }
        zip.delete()
        return dest
    }

    fun uninstall(id: String) { File(root, id).deleteRecursively() }

    private fun download(m: ToolchainManifest, part: File, onProgress: (Long, Long) -> Unit) {
        var have = if (part.exists()) part.length() else 0L
        if (have > m.sizeBytes) { part.delete(); have = 0 }
        if (have == m.sizeBytes) return
        val c = URL(m.url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000; c.readTimeout = 30_000
        if (have > 0) c.setRequestProperty("Range", "bytes=$have-")
        try {
            val code = c.responseCode
            if (code == 200) have = 0       // servidor ignorou o Range: recomeça
            else if (code != 206) error("HTTP $code ao baixar o toolchain")
            FileOutputStream(part, have > 0).use { out ->
                c.inputStream.use { inp ->
                    val buf = ByteArray(256 * 1024)
                    var done = have
                    while (true) {
                        val n = inp.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        onProgress(done, m.sizeBytes)
                    }
                }
            }
        } finally { c.disconnect() }
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { i -> val b = ByteArray(256 * 1024); while (true) { val n = i.read(b); if (n < 0) break; md.update(b, 0, n) } }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun unzip(zip: File, dest: File) {
        val base = dest.canonicalPath + File.separator
        ZipInputStream(zip.inputStream().buffered()).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val out = File(dest, e.name)
                require(out.canonicalPath.startsWith(base)) { "entrada inválida no zip: ${e.name}" }   // zip-slip
                if (e.isDirectory) { out.mkdirs(); continue }
                out.parentFile?.mkdirs()
                FileOutputStream(out).use { zin.copyTo(it, 256 * 1024) }
            }
        }
    }
}
