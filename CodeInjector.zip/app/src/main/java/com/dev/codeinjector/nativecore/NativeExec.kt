package com.dev.codeinjector.nativecore

import java.io.File
import java.util.concurrent.atomic.AtomicLong

enum class ExecStatus { OK, COMPILE_ERROR, TIMEOUT, CRASHED, CANCELED, NO_TOOLCHAIN, INTERNAL;
    companion object { fun of(i: Int) = entries.getOrElse(i) { ExecStatus.INTERNAL } }
}

/** [exitCode] é o nº do sinal (ex.: 11 = SIGSEGV) quando status == CRASHED. Tempos em microssegundos. */
class ExecResult(
    val requestId: Long, val status: ExecStatus, val exitCode: Int, val cacheHit: Boolean,
    val compileUs: Long, val runUs: Long, val output: String,
)

/**
 * Compila C++ para .so com o toolchain baixado e executa com dlopen, num processo filho isolado
 * (crash/timeout do programa do usuário não derrubam o app). Uma execução por vez.
 * Cache por hash: fonte igual + mesmas flags => nenhuma recompilação.
 */
object NativeExec {
    // Pré-compilado uma vez (PCH): corta a maior parte do tempo de cada compilação.
    private const val DEFAULT_PCH = "#include <iostream>\n#include <vector>\n#include <string>\n#include <map>\n" +
        "#include <algorithm>\n#include <cmath>\n#include <cstdio>\n#include <cstdlib>\n"

    private val ids = AtomicLong(0)
    @Volatile private var callback: ((ExecResult) -> Unit)? = null

    private val listener = object : NativeCore.ExecListener {
        override fun onExecDone(requestId: Long, status: Int, exitCode: Int, cacheHit: Boolean, compileUs: Long, runUs: Long, output: String) {
            callback?.invoke(ExecResult(requestId, ExecStatus.of(status), exitCode, cacheHit, compileUs, runUs, output))
        }
    }

    /**
     * Modo EXECUTÁVEL. [clang]/[lld] precisam ser executáveis pelo app:
     *  - dentro do APK como lib*.so (nativeLibraryDir; ver [apkTool]), ou
     *  - em filesDir, se o app tiver targetSdk <= 28.
     * [toolchainDir] precisa conter `sysroot/` e `clang-resource/` (pacote do ToolchainManager).
     * @param onResult roda numa thread nativa; despache para a main antes de mexer em UI.
     */
    fun initExecutables(toolchainDir: File, clang: File, lld: File, cacheDir: File, workDir: File, toolchainId: String,
                        onResult: (ExecResult) -> Unit): Boolean {
        if (!NativeCore.available) return false
        callback = onResult
        return NativeCore.nExecInit(toolchainDir.path, clang.path, lld.path, cacheDir.path, workDir.path, toolchainId, DEFAULT_PCH, listener)
    }

    /** Modo BIBLIOTECA (libci_clang_host.so dentro de [toolchainDir]). */
    fun initHostLibrary(toolchainDir: File, cacheDir: File, workDir: File, toolchainId: String, onResult: (ExecResult) -> Unit): Boolean {
        if (!NativeCore.available) return false
        callback = onResult
        return NativeCore.nExecInit(toolchainDir.path, "", "", cacheDir.path, workDir.path, toolchainId, DEFAULT_PCH, listener)
    }

    /** Executável empacotado no APK como jniLibs/<abi>/lib<name>.so (exige extractNativeLibs=true). */
    fun apkTool(ctx: android.content.Context, name: String): File = File(ctx.applicationInfo.nativeLibraryDir, "lib$name.so")

    /** Retorna o id da requisição, ou null se já houver uma em curso / motor não iniciado. */
    fun run(source: String, stdin: String = "", flags: List<String> = emptyList(), compileTimeoutMs: Int = 60_000, runTimeoutMs: Int = 10_000): Long? {
        val id = ids.incrementAndGet()
        return if (NativeCore.nBuildAndRun(source, stdin, flags.joinToString("\n"), compileTimeoutMs, runTimeoutMs, id)) id else null
    }

    fun cancel() { if (NativeCore.available) NativeCore.nExecCancel() }
}
