package com.dev.codeinjector.nativecore

import android.graphics.Typeface
import android.os.Bundle
import androidx.activity.ComponentActivity

/** Fatia vertical de ponta a ponta: texto -> lexer C++ (thread pool) -> cena -> OpenGL ES. Arraste para rolar. */
class NativeDemoActivity : ComponentActivity() {
    private var analyzer: NativeAnalyzer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val view = NativeSurfaceView(this)
        setContentView(view)
        if (!NativeCore.available) { title = "libcodeinjector_native não carregou"; return }

        analyzer = NativeAnalyzer(onResult = { r ->
            android.util.Log.i("CI", "spans=${r.spanCount} issues=${r.issueCount} truncated=${r.truncated}")
        })
        NativeCore.start(0, analyzer!!)   // o motor é do processo; sem nShutdown aqui para sobreviver à rotação

        val tf = Typeface.createFromAsset(assets, "fonts/JetBrainsMono-Regular.ttf")
        GlyphAtlas.upload(GlyphAtlas.build(tf, 14f * resources.displayMetrics.scaledDensity))

        val sample = buildString {
            repeat(300) { i ->
                append("@decorator\nclass Foo$i:\n    def run(self, x=0x1F):\n        \"\"\"doc\"\"\"\n")
                append("        return print(\"ok\", x + 3.14) # $i\n\n")
            }
            append("broken = (1, [2)\n")
        }
        view.maxScroll = 1_000_000f
        analyzer!!.submit(sample)
    }
}
