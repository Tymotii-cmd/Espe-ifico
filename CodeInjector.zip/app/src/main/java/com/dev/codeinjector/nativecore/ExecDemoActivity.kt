package com.dev.codeinjector.nativecore

import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import java.io.File

/** Tela de teste: escreva C++, toque em Executar. Mostra status, saída e tempos de cada fase (cache hit = ~0 ms de compilação). */
class ExecDemoActivity : ComponentActivity() {
    private lateinit var out: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val code = EditText(this).apply {
            setText(SAMPLE); typeface = Typeface.MONOSPACE; textSize = 13f; gravity = android.view.Gravity.TOP
        }
        val run = Button(this).apply { text = "Executar" }
        val cancel = Button(this).apply { text = "Cancelar" }
        out = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 12f; setTextIsSelectable(true) }
        val row = LinearLayout(this).apply { addView(run); addView(cancel) }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            addView(code, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            addView(ScrollView(this@ExecDemoActivity).apply { addView(out) }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        })

        val ready = setup()
        run.isEnabled = ready
        cancel.isEnabled = ready
        run.setOnClickListener {
            out.text = "compilando..."
            if (NativeExec.run(code.text.toString()) == null) out.text = "ocupado: já há uma execução em curso"
        }
        cancel.setOnClickListener { NativeExec.cancel() }
    }

    private fun setup(): Boolean {
        if (!NativeCore.available) { out.text = "libcodeinjector_native não carregou"; return false }
        val dir = ToolchainManager(this).installedDir(ToolchainConfig.ID)
        if (dir == null) {
            out.text = "Toolchain '${ToolchainConfig.ID}' não instalado."
            if (ToolchainConfig.URL.isNotBlank()) offerDownload()
            else out.append("\nPublique o pacote (tools/make_sysroot_pack.sh) e preencha ToolchainConfig.kt.")
            return false
        }
        val clang = NativeExec.apkTool(this, "clang")
        val lld = NativeExec.apkTool(this, "lld")
        if (!clang.exists() || !lld.exists()) {
            out.text = "Faltam libclang.so / liblld.so em jniLibs (modo A). Compile com -Pci.clangInApk=true."
            return false
        }
        val ok = NativeExec.initExecutables(dir, clang, lld, File(filesDir, "ci-build"), File(filesDir, "ci-work"), ToolchainConfig.ID) { r ->
            runOnUiThread { show(r) }
        }
        out.text = if (ok) "pronto" else "toolchain inutilizável (veja: adb logcat -s ci-native)"
        return ok
    }

    private fun offerDownload() {
        Thread {
            try {
                ToolchainManager(this).install(ToolchainConfig.manifest) { d, t ->
                    runOnUiThread { out.text = "baixando toolchain: ${if (t > 0) d * 100 / t else 0}%" }
                }
                runOnUiThread { recreate() }
            } catch (e: Exception) {
                runOnUiThread { out.text = "falha ao instalar: ${e.message}" }
            }
        }.start()
    }

    private fun show(r: ExecResult) {
        out.text = buildString {
            append("${r.status}")
            if (r.status == ExecStatus.OK) append("  exit=${r.exitCode}")
            if (r.status == ExecStatus.CRASHED) append("  sinal=${r.exitCode}")
            append("\ncompilação: ${if (r.cacheHit) "cache" else "${r.compileUs / 1000} ms"}   execução: ${r.runUs / 1000} ms\n\n")
            append(r.output)
        }
    }

    private companion object {
        const val SAMPLE = "#include <iostream>\n#include <vector>\n\nint main() {\n    std::vector<int> v{1, 2, 3};\n" +
            "    int s = 0;\n    for (int x : v) s += x;\n    std::cout << \"soma = \" << s << std::endl;\n    return 0;\n}\n"
    }
}
