package com.dev.codeinjector.nativecore

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import java.nio.ByteBuffer
import kotlin.math.ceil

/**
 * Atlas A8 em grade (ASCII 32..126 + 1 célula branca). Gerado uma vez pelo Canvas do Android e enviado ao
 * renderer por buffer direto; o renderer guarda uma cópia na CPU e recria a textura sempre que o contexto GL
 * for reconstruído.
 */
object GlyphAtlas {
    class Built(
        val pixels: ByteBuffer, val w: Int, val h: Int, val stride: Int,
        val cols: Int, val rows: Int, val cellW: Int, val cellH: Int,
    )

    private const val FIRST = 32
    private const val COUNT = 95
    private const val COLS = 16

    fun build(typeface: Typeface, textSizePx: Float): Built {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = typeface; textSize = textSizePx; color = Color.WHITE
        }
        val fm = paint.fontMetrics
        val cellW = ceil(paint.measureText("M")).toInt().coerceAtLeast(1)
        val cellH = ceil(fm.descent - fm.ascent).toInt().coerceAtLeast(1)
        val cells = COUNT + 1
        val rows = (cells + COLS - 1) / COLS
        val bmp = Bitmap.createBitmap(COLS * cellW, rows * cellH, Bitmap.Config.ALPHA_8)
        val canvas = Canvas(bmp)
        for (i in 0 until COUNT) {
            val x = (i % COLS) * cellW
            val y = (i / COLS) * cellH
            canvas.drawText((FIRST + i).toChar().toString(), x.toFloat(), y - fm.ascent, paint)
        }
        val wx = (COUNT % COLS) * cellW
        val wy = (COUNT / COLS) * cellH
        canvas.drawRect(wx.toFloat(), wy.toFloat(), (wx + cellW).toFloat(), (wy + cellH).toFloat(), paint)

        val buf = NativeCore.newBuffer(bmp.byteCount)
        bmp.copyPixelsToBuffer(buf)
        buf.rewind()
        val built = Built(buf, bmp.width, bmp.height, bmp.rowBytes, COLS, rows, cellW, cellH)
        bmp.recycle()
        return built
    }

    fun upload(a: Built) = NativeCore.nSetAtlas(a.pixels, a.w, a.h, a.stride, a.cols, a.rows, a.cellW, a.cellH)
}
