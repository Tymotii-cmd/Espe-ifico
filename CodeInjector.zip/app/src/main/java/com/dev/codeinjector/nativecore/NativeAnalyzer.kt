package com.dev.codeinjector.nativecore

import java.nio.ByteBuffer

/** Resultado da análise. spans = triplas (start, end, tok); issues = 8 ints cada (ver Issue em py_lexer.hpp). */
class AnalysisResult(val spans: IntArray, val issues: IntArray, val truncated: Boolean) {
    val spanCount get() = spans.size / 3
    val issueCount get() = issues.size / 8
}

/**
 * Análise assíncrona com UMA requisição em voo: se chegar texto novo enquanto roda, só o mais recente
 * fica pendente (latest-wins). Buffers diretos alocados uma vez; nenhuma alocação por requisição além
 * do IntArray do resultado.
 *
 * [onResult] roda numa thread nativa: despache para a main antes de mexer em UI.
 */
class NativeAnalyzer(
    private val onResult: (AnalysisResult) -> Unit,
    maxChars: Int = 1 shl 21,
    outInts: Int = 1 shl 16,
) : NativeCore.Listener {
    private val src: ByteBuffer = NativeCore.newBuffer(maxChars * 2)
    private val out: ByteBuffer = NativeCore.newBuffer(outInts * 4)
    private val lock = Any()
    private var busy = false
    private var pending: String? = null
    private var pendingPublish = true
    private var nextId = 0L

    /** [publish] = true também envia o texto + spans ao renderer OpenGL. */
    fun submit(text: String, publish: Boolean = true) {
        synchronized(lock) {
            if (busy) { pending = text; pendingPublish = publish; return }
            busy = true
        }
        start(text, publish)
    }

    private fun start(text: String, publish: Boolean) {
        val n = NativeCore.putText(src, text)
        val ok = n >= 0 && NativeCore.nAnalyzeAsync(src, n, out, synchronized(lock) { ++nextId }, publish)
        if (!ok) synchronized(lock) { busy = false }
    }

    override fun onAnalysisDone(requestId: Long, spanCount: Int, issueCount: Int, truncated: Boolean) {
        val res = if (spanCount >= 0) read(spanCount, issueCount, truncated) else null  // lê ANTES de liberar `out`
        var next: String? = null
        var publish = true
        synchronized(lock) {
            next = pending; publish = pendingPublish; pending = null
            if (next == null) busy = false
        }
        res?.let(onResult)
        next?.let { start(it, publish) }
    }

    private fun read(ns: Int, ni: Int, truncated: Boolean): AnalysisResult {
        val ib = out.asIntBuffer()
        val issues = IntArray(ni * 8)
        val spans = IntArray(ns * 3)
        ib.position(4); ib.get(issues)
        ib.get(spans)
        return AnalysisResult(spans, issues, truncated)
    }
}
