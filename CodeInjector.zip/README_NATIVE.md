# Motor nativo (C++ / JNI / OpenGL ES)

```
app/src/main/cpp/
  core/     MpmcQueue (lock-free), Task (sem heap), ThreadPool, Parker, UTF-8<->16, file_io, GapBuffer, LineIndex
  syntax/   py_lexer: port do lex() do SyntaxAnalyzer.kt, direto em UTF-16 (offsets idênticos aos do Kotlin)
  scene/    Snapshot + SnapshotPool (pré-alocado), scene_builder (texto -> quads, 100% CPU e testado no PC)
  render/   Renderer: thread própria, fila de eventos lock-free, EGL + GLES 3.0, VBO/IBO/VAO, sob demanda
  jni/      native_bridge: RegisterNatives, só direct buffers, threads do pool anexadas à JVM
  tests/    testes de host (CI roda normal + TSAN + ASAN/UBSAN)
app/src/main/java/.../nativecore/   NativeCore, NativeAnalyzer, GlyphAtlas, NativeSurfaceView, NativeDemoActivity
```

## Fluxo de dados
Kotlin `String` -> `putText` (direct buffer) -> `nAnalyzeAsync` -> **1 memcpy** para um Snapshot do pool
(necessário: evita data race com o buffer do Kotlin) -> worker: lexer -> resultado serializado no buffer
direto de saída (memcpy de structs) -> callback Kotlin; se `publish`, o Snapshot vai para o renderer, que
monta os quads e desenha. Nenhuma alocação por requisição em regime.

Leitura de arquivo: `ParcelFileDescriptor.fd` -> `nReadFile` faz `pread` no FIM do buffer destino e
decodifica UTF-8->UTF-16 in-place: zero cópias, zero malloc, sem mmap (sem SIGBUS se o arquivo encolher).

## Ciclo de vida da Surface
Todo estado de GPU nasce de estado de CPU (atlas, snapshot). Context lost, `onPause`/janela invisível ou
`surfaceDestroyed` => EGL + recursos GL são destruídos; o próximo frame recria tudo. `surfaceDestroyed`
bloqueia (com timeout de 1,5 s) até a thread de render soltar a ANativeWindow.

## Rodar os testes de host
    cmake -S app/src/main/cpp -B build-host -DCI_BUILD_TESTS=ON -DCMAKE_BUILD_TYPE=Release
    cmake --build build-host && ctest --test-dir build-host --output-on-failure
    # sanitizers: -DCI_SANITIZE=thread   ou   -DCI_SANITIZE="address,undefined"

## Testar no aparelho
Instale o APK e abra o ícone **CI Native Demo** (arraste para rolar). `adb logcat -s CI ci-render ci-native`.

## Trocar o realce do editor Compose pelo nativo
`NativeAnalyzer.submit(text, publish = false)` -> `AnalysisResult.spans` (start, end, tok) -> montar o
`AnnotatedString` em vez de chamar `SyntaxAnalyzer.highlight`. Os `issues` seguem o enum de `py_lexer.hpp`;
a tradução para mensagens pt-BR (`translate()` do Kotlin) continua no Kotlin.

## Limites conhecidos
* Não há ainda: seleção/cursor/IME no renderer GL, glifos fora do ASCII (viram `?`), tema configurável.
* O lexer C++ aproxima `Char.isLetter()` para letras não-ASCII.
* O `TermuxRunner.kt` (código morto, ninguém o chamava) foi removido. O `CodeRunner` (Judge0) também não é
  chamado por ninguém e usava um enum `Language` inexistente (não compilava); defini o enum em `CodeRunner.kt`.
* O editor (`CodeEditorScreen`) só executa Python (PyRunner). Rodar C++ pelo botão do editor ainda NÃO está ligado:
  hoje só a tela "CI Exec Demo" usa o motor de compilação.

Ver também README_TOOLCHAIN.md (compilar e executar C++ no aparelho).
